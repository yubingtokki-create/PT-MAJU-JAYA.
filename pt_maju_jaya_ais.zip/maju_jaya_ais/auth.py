from functools import wraps
from flask import session, redirect, url_for, flash, request
from database import get_connection


def get_current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    conn = get_connection()
    try:
        user = conn.execute(
            """SELECT u.*, r.role_name FROM users u JOIN roles r ON r.role_id=u.role_id
               WHERE u.user_id=? AND u.is_active=1""", (user_id,)
        ).fetchone()
        return user
    finally:
        conn.close()


def has_permission(user, permission_code):
    if not user:
        return False
    conn = get_connection()
    try:
        row = conn.execute(
            """SELECT 1 FROM role_permissions rp
               JOIN permissions p ON p.permission_id=rp.permission_id
               WHERE rp.role_id=? AND p.permission_code=?""",
            (user["role_id"], permission_code),
        ).fetchone()
        return bool(row)
    finally:
        conn.close()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not get_current_user():
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def permission_required(permission_code):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = get_current_user()
            if not user:
                return redirect(url_for("login", next=request.path))
            if not has_permission(user, permission_code):
                from services import add_audit
                add_audit(user, "ACCESS_DENIED", "AUTHORIZATION", kwargs.get("id"), result="BLOCKED", reason=f"Missing permission: {permission_code}")
                flash("You are not authorized to perform this action.", "error")
                return redirect(url_for("access_denied"))
            return view(*args, **kwargs)
        return wrapped
    return decorator
