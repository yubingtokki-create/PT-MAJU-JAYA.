from datetime import date, timedelta
from decimal import Decimal
import os
import sqlite3
from security import hash_password

from database import get_connection, init_db
from services import add_audit, add_notification, inventory_adjust, money, post_accounting_entry, update_invoice_status

DB_PATH = os.path.join(os.path.dirname(__file__), "maju_jaya.db")

ROLES = [
    ("Salesperson", "Create and submit sales orders."),
    ("Credit Officer", "Review and decide credit approvals."),
    ("Warehouse / Inventory Staff", "Operate warehouse and inventory workflows."),
    ("Accounting / Billing Staff", "Issue invoices, AR, and reconciliation."),
    ("Cashier", "Record customer cash receipts."),
    ("Manager", "Management review and configured approvals."),
    ("System Administrator", "System setup and user/master administration."),
]

PERMISSIONS = [
    ("dashboard.view", "View dashboard"),
    ("customer.view", "View customers"), ("customer.create", "Create customers"), ("customer.edit", "Edit customer status / verification"),
    ("product.view", "View products"), ("product.create", "Create products"), ("product.edit", "Edit product status"),
    ("sales_order.view", "View Sales Orders"), ("sales_order.create", "Create Sales Orders"), ("sales_order.submit", "Submit Sales Orders"),
    ("credit_approval.view", "View credit approvals"), ("credit_approval.decide", "Approve/reject credit"),
    ("manager_approval.view", "View manager approvals"), ("manager_approval.decide", "Decide manager approvals"),
    ("shipping.view", "View shipping"), ("shipping.create", "Create/confirm shipping"), ("shipping.cancel", "Cancel/reverse shipping"),
    ("invoice.view", "View invoices"), ("invoice.create", "Issue invoices"),
    ("cash_receipt.view", "View receipts"), ("cash_receipt.create", "Record receipts"),
    ("ar.view", "View AR/AP"), ("credit_note.create", "Create AR credit notes"),
    ("inventory.view", "View inventory"), ("inventory.receive", "Receive inventory"), ("inventory.transfer", "Transfer stock"), ("inventory.adjust", "Adjust inventory"),
    ("bank_reconciliation.view", "View bank reconciliation"), ("bank_reconciliation.reconcile", "Reconcile bank"), ("bank_reconciliation.manage", "Enter bank demo data"),
    ("report.view", "View reports"), ("audit.view", "View audit trail"), ("user.manage", "Manage users"),
]

ROLE_PERMS = {
    "Salesperson": ["dashboard.view","customer.view","product.view","sales_order.view","sales_order.create","sales_order.submit"],
    "Credit Officer": ["dashboard.view","customer.view","product.view","sales_order.view","credit_approval.view","credit_approval.decide","report.view"],
    "Warehouse / Inventory Staff": ["dashboard.view","customer.view","product.view","sales_order.view","shipping.view","shipping.create","inventory.view","inventory.receive","inventory.transfer","inventory.adjust","report.view"],
    "Accounting / Billing Staff": ["dashboard.view","customer.view","product.view","sales_order.view","shipping.view","invoice.view","invoice.create","cash_receipt.view","ar.view","credit_note.create","inventory.view","bank_reconciliation.view","bank_reconciliation.reconcile","report.view"],
    "Cashier": ["dashboard.view","customer.view","product.view","invoice.view","cash_receipt.view","cash_receipt.create","report.view"],
    "Manager": ["dashboard.view","customer.view","product.view","sales_order.view","credit_approval.view","shipping.view","shipping.create","shipping.cancel","invoice.view","cash_receipt.view","ar.view","credit_note.create","inventory.view","report.view","bank_reconciliation.view","bank_reconciliation.reconcile","bank_reconciliation.manage","audit.view","manager_approval.view","manager_approval.decide"],
    "System Administrator": [p[0] for p in PERMISSIONS],
}

USERS = [
    ("EMP001","Sarah Wijaya","Salesperson","Sales@123"),
    ("EMP002","Daniel Pratama","Credit Officer","Credit@123"),
    ("EMP003","Kevin Santoso","Warehouse / Inventory Staff","Warehouse@123"),
    ("EMP004","Olivia Tan","Accounting / Billing Staff","Account@123"),
    ("EMP005","Amanda Putri","Cashier","Cashier@123"),
    ("EMP006","Michael Hartono","Manager","Manager@123"),
    ("EMP007","Reza Gunawan","System Administrator","Admin@123"),
]

PRODUCTS = [
    ("PROD-000001","Laptop Business Pro 14","Business Laptop","NusaTech","Professional 14-inch business laptop","Unit",15000000,16,10000000),
    ("PROD-000002","Laptop Business Pro 15","Business Laptop","NusaTech","Professional 15-inch business laptop","Unit",17500000,12,11500000),
    ("PROD-000003","Laser Printer Pro","Office Printer","PrintWorks","Monochrome laser printer","Unit",6500000,16,4200000),
    ("PROD-000004","Multifunction Color Printer","Office Printer","PrintWorks","Color MFP for office use","Unit",9200000,8,6100000),
    ("PROD-000005","Business Projector 5000","Projector","VisionPeak","5000-lumen business projector","Unit",12000000,6,7800000),
    ("PROD-000006","Network Switch 24-Port","Networking Equipment","Connectra","24-port managed switch","Unit",3800000,30,2450000),
]

CUSTOMERS = [
    ("CUST-000001","PT Teknologi Nusantara","Corporate","01.111.222.3-444.555","Budi Santosa","021-5551001","budi@tekno-nusantara.demo",100000000,2,"ACTIVE"),
    ("CUST-000002","PT Ritel Data Abadi","Corporate","01.222.333.4-555.666","Nina Lestari","021-5551002","nina@riteldata.demo",50000000,2,"ACTIVE"),
    ("CUST-000003","PT Cakrawala Office","Corporate","01.333.444.5-666.777","Arif Rahman","021-5551003","arif@cakrawala-office.demo",75000000,3,"ACTIVE"),
    ("CUST-000004","CV Sumber Solusi","SME","01.444.555.6-777.888","Rani Kusuma","021-5551004","rani@sumbersolusi.demo",30000000,2,"ACTIVE"),
    ("CUST-000005","PT Inovasi Digital Sentra","Corporate","01.555.666.7-888.999","Dimas Hadi","021-5551005","dimas@inovasi-digital.demo",60000000,3,"ACTIVE"),
    ("CUST-000006","PT Arsip Prima","Corporate","01.666.777.8-999.000","Tari Wulan","021-5551006","tari@arsipprima.demo",20000000,1,"INACTIVE"),
]


def seed():
    init_db()
    conn = get_connection()
    try:
        # Clear data in dependency order so seed.py can be rerun.
        tables = ["notifications","audit_logs","accounting_entry_lines","accounting_entries","inventory_adjustments","stock_transfers","goods_receipts","inventory_movements","inventory_stock","bank_reconciliations","bank_transactions","cash_receipts","invoice_details","invoices","shipping_details","shippings","credit_approvals","manager_approvals","sales_order_details","sales_orders","credit_notes","product_accounts","products","customers","warehouses","chart_of_accounts","role_permissions","permissions","users","payment_terms","roles"]
        for table in tables: conn.execute(f"DELETE FROM {table}")
        conn.commit()

        for name, desc in ROLES:
            conn.execute("INSERT INTO roles(role_name,description) VALUES(?,?)",(name,desc))
        for code, desc in PERMISSIONS:
            conn.execute("INSERT INTO permissions(permission_code,description) VALUES(?,?)",(code,desc))
        role_ids={r["role_name"]:r["role_id"] for r in conn.execute("SELECT * FROM roles").fetchall()}
        perm_ids={p["permission_code"]:p["permission_id"] for p in conn.execute("SELECT * FROM permissions").fetchall()}
        for role, codes in ROLE_PERMS.items():
            for code in codes:
                conn.execute("INSERT INTO role_permissions(role_id,permission_id) VALUES(?,?)",(role_ids[role],perm_ids[code]))
        terms=[("CASH","CASH",0),("NET30","NET 30",30),("NET60","NET 60",60)]
        for t in terms: conn.execute("INSERT INTO payment_terms(term_code,term_name,days) VALUES(?,?,?)",t)
        term_ids={r["term_code"]:r["payment_term_id"] for r in conn.execute("SELECT * FROM payment_terms").fetchall()}
        for eid,name,role,pwd in USERS:
            conn.execute("INSERT INTO users(employee_id,employee_name,username,password_hash,role_id) VALUES(?,?,?,?,?)",(eid,name,eid,hash_password(pwd),role_ids[role]))
        user_ids={r["employee_id"]:r["user_id"] for r in conn.execute("SELECT * FROM users").fetchall()}
        coa=[
            ("1010","Cash / Bank","ASSET"),("1100","Accounts Receivable","ASSET"),("1200","Inventory - Computer Equipment","ASSET"),("1210","Inventory - Printing Equipment","ASSET"),("1220","Inventory - Projector","ASSET"),("1230","Inventory - Networking","ASSET"),
            ("2100","Accounts Payable","LIABILITY"),("2200","VAT Payable","LIABILITY"),("4100","Sales Revenue - Computer Equipment","REVENUE"),("4110","Sales Revenue - Printing Equipment","REVENUE"),("4120","Sales Revenue - Projector","REVENUE"),("4130","Sales Revenue - Networking","REVENUE"),
            ("5100","Cost of Goods Sold - Computer Equipment","EXPENSE"),("5110","Cost of Goods Sold - Printing Equipment","EXPENSE"),("5120","Cost of Goods Sold - Projector","EXPENSE"),("5130","Cost of Goods Sold - Networking","EXPENSE"),
        ]
        for row in coa: conn.execute("INSERT INTO chart_of_accounts(account_code,account_name,account_type) VALUES(?,?,?)",row)
        coa_ids={r["account_code"]:r["account_id"] for r in conn.execute("SELECT * FROM chart_of_accounts").fetchall()}
        for p in PRODUCTS:
            conn.execute("INSERT INTO products(product_code,product_name,category,brand,description,unit,selling_price,available_stock,standard_cost,product_status) VALUES(?,?,?,?,?,?,?,?,?,'ACTIVE')",p)
        prod_ids={r["product_code"]:r["product_id"] for r in conn.execute("SELECT * FROM products").fetchall()}
        mapping={
            "PROD-000001":("1200","4100","5100"),"PROD-000002":("1200","4100","5100"),"PROD-000003":("1210","4110","5110"),"PROD-000004":("1210","4110","5110"),"PROD-000005":("1220","4120","5120"),"PROD-000006":("1230","4130","5130")}
        for code,accs in mapping.items(): conn.execute("INSERT INTO product_accounts(product_id,inventory_account_id,sales_account_id,cogs_account_id) VALUES(?,?,?,?)",(prod_ids[code],coa_ids[accs[0]],coa_ids[accs[1]],coa_ids[accs[2]]))
        warehouses=[("WH-A","Main Warehouse","Jakarta Business Park"),("WH-B","Branch Warehouse","West Jakarta Distribution Hub")]
        for w in warehouses: conn.execute("INSERT INTO warehouses(warehouse_code,warehouse_name,address) VALUES(?,?,?)",w)
        wh_ids={r["warehouse_code"]:r["warehouse_id"] for r in conn.execute("SELECT * FROM warehouses").fetchall()}
        for code,qty in {"PROD-000001":16,"PROD-000002":12,"PROD-000003":16,"PROD-000004":8,"PROD-000005":6,"PROD-000006":30}.items():
            a=qty//2; b=qty-a
            conn.execute("INSERT INTO inventory_stock(product_id,warehouse_id,quantity) VALUES(?,?,?)",(prod_ids[code],wh_ids["WH-A"],a))
            conn.execute("INSERT INTO inventory_stock(product_id,warehouse_id,quantity) VALUES(?,?,?)",(prod_ids[code],wh_ids["WH-B"],b))
            u=user_ids["EMP003"]
            conn.execute("INSERT INTO inventory_movements(movement_number,product_id,warehouse_id,movement_type,quantity_change,reference_type,reference_id,reason,unit_cost,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)",(f"IM-{len(conn.execute('SELECT * FROM inventory_movements').fetchall())+1:06d}",prod_ids[code],wh_ids["WH-A"],"OPENING",a,"SEED",None,"Opening balance",dict(PRODUCTS)[code] if False else next(x[8] for x in PRODUCTS if x[0]==code),u))
            conn.execute("INSERT INTO inventory_movements(movement_number,product_id,warehouse_id,movement_type,quantity_change,reference_type,reference_id,reason,unit_cost,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)",(f"IM-{len(conn.execute('SELECT * FROM inventory_movements').fetchall())+1:06d}",prod_ids[code],wh_ids["WH-B"],"OPENING",b,"SEED",None,"Opening balance",next(x[8] for x in PRODUCTS if x[0]==code),u))

        for c in CUSTOMERS:
            conn.execute("""INSERT INTO customers(customer_code,customer_name,customer_type,npwp,contact_person,phone,email,email_verified,billing_address,delivery_address,city,province,postal_code,credit_limit,payment_term_id,customer_status,created_by) VALUES(?,?,?,?,?,?,?,1,?,?,?,?,?,?,?, ?,?)""",(c[0],c[1],c[2],c[3],c[4],c[5],c[6],"Jl. Demo Billing 1","Jl. Demo Delivery 1","Jakarta","DKI Jakarta","12345",c[7],term_ids[{1:"CASH",2:"NET30",3:"NET60"}[c[8] if isinstance(c[8],int) else 2]],"ACTIVE" if c[9] not in ("ACTIVE","INACTIVE") else c[9],user_ids["EMP007"]))
        # Fix customer term IDs from tuple structure.
        conn.execute("UPDATE customers SET payment_term_id=? WHERE customer_code='CUST-000001'",(term_ids["NET30"],))
        conn.execute("UPDATE customers SET payment_term_id=? WHERE customer_code='CUST-000002'",(term_ids["NET30"],))
        conn.execute("UPDATE customers SET payment_term_id=? WHERE customer_code='CUST-000003'",(term_ids["NET60"],))
        conn.execute("UPDATE customers SET payment_term_id=? WHERE customer_code='CUST-000004'",(term_ids["NET30"],))
        conn.execute("UPDATE customers SET payment_term_id=? WHERE customer_code='CUST-000005'",(term_ids["NET60"],))
        conn.execute("UPDATE customers SET payment_term_id=? WHERE customer_code='CUST-000006'",(term_ids["CASH"],))

        # Helper functions for demo transaction rows.
        def insert_so(num, cust, salesperson, stype, term, lines, status="DRAFT", shipping_cost=0, notes=None):
            subtotal=sum(Decimal(str(q))*Decimal(str(price)) for _,q,price,disc in lines)
            disc=sum((Decimal(str(q))*Decimal(str(price))*Decimal(str(disc))/Decimal('100')) for _,q,price,disc in lines)
            tax=((subtotal-disc+Decimal(str(shipping_cost)))*Decimal('0.11')).quantize(Decimal('0.01'))
            total=(subtotal-disc+Decimal(str(shipping_cost))+tax).quantize(Decimal('0.01'))
            cur=conn.execute("SELECT customer_id FROM customers WHERE customer_code=?",(cust,)).fetchone()[0]
            sid=user_ids[salesperson]
            row=conn.execute("""INSERT INTO sales_orders(so_number,order_date,customer_id,salesperson_id,sales_type,payment_term_id,delivery_date,delivery_address,shipping_cost,tax,subtotal,discount,grand_total,order_status,customer_notes,internal_notes,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(num,date.today().isoformat(),cur,sid,stype,term_ids[term],(date.today()+timedelta(days=7)).isoformat(),"Jl. Demo Delivery 1",shipping_cost,tax,subtotal,disc,total,status,notes or "Demo transaction","AIS seed data",sid))
            soid=row.lastrowid
            for pcode,q,price,disc_pct in lines:
                line_sub=Decimal(str(q))*Decimal(str(price)); da=line_sub*Decimal(str(disc_pct))/Decimal('100')
                conn.execute("INSERT INTO sales_order_details(sales_order_id,product_id,quantity,unit_price,discount_percentage,discount_amount,line_subtotal) VALUES(?,?,?,?,?,?,?)",(soid,prod_ids[pcode],q,price,disc_pct,da,line_sub))
            return soid,total,cur

        def ship(soid,num,items,wh="WH-A"):
            row=conn.execute("SELECT * FROM sales_orders WHERE sales_order_id=?",(soid,)).fetchone()
            w=wh_ids[wh]
            sh=conn.execute("INSERT INTO shippings(shipping_number,sales_order_id,shipping_date,delivery_address,shipping_status,shipped_by) VALUES(?,?,?,?, 'SHIPPED',?)",(num,soid,date.today().isoformat(),row["delivery_address"],user_ids["EMP003"]))
            shid=sh.lastrowid
            for pcode,qty in items:
                sod=conn.execute("SELECT * FROM sales_order_details WHERE sales_order_id=? AND product_id=?",(soid,prod_ids[pcode])).fetchone()
                cost=next(x[8] for x in PRODUCTS if x[0]==pcode)
                conn.execute("INSERT INTO shipping_details(shipping_id,sales_order_detail_id,product_id,quantity_shipped,unit_cost,warehouse_id) VALUES(?,?,?,?,?,?)",(shid,sod["sales_order_detail_id"],prod_ids[pcode],qty,cost,w))
                inventory_adjust(conn,prod_ids[pcode],w,-Decimal(str(qty)),user_ids["EMP003"],"SHIPMENT","SHIPPING",shid,reason=num,unit_cost=cost)
                pa=conn.execute("SELECT * FROM product_accounts WHERE product_id=?",(prod_ids[pcode],)).fetchone()
                cogs=Decimal(str(qty))*Decimal(str(cost))
                post_accounting_entry(conn,user_ids["EMP003"],"SHIPPING",shid,f"Seed COGS {num}",[(pa["cogs_account_id"],cogs,0,num),(pa["inventory_account_id"],0,cogs,num)])
            return shid

        def invoice_from_shipping(shid,num):
            sh=conn.execute("SELECT * FROM shippings WHERE shipping_id=?",(shid,)).fetchone(); so=conn.execute("SELECT * FROM sales_orders WHERE sales_order_id=?",(sh["sales_order_id"],)).fetchone()
            ds=conn.execute("SELECT sd.*,sod.unit_price,sod.discount_percentage FROM shipping_details sd JOIN sales_order_details sod ON sod.sales_order_detail_id=sd.sales_order_detail_id WHERE sd.shipping_id=?",(shid,)).fetchall()
            subtotal=sum(Decimal(str(d["quantity_shipped"]))*Decimal(str(d["unit_price"]))*(Decimal('1')-Decimal(str(d["discount_percentage"]))/Decimal('100')) for d in ds)
            tax=(subtotal*Decimal('0.11')).quantize(Decimal('0.01')); amount=(subtotal+tax).quantize(Decimal('0.01'))
            c=conn.execute("SELECT customer_id FROM customers WHERE customer_id=?",(so["customer_id"],)).fetchone()[0]
            term=conn.execute("SELECT days FROM payment_terms WHERE payment_term_id=?",(so["payment_term_id"],)).fetchone()[0]
            inv=conn.execute("INSERT INTO invoices(invoice_number,sales_order_id,shipping_id,invoice_date,due_date,customer_id,invoice_amount,paid_amount,outstanding_amount,invoice_status,created_by) VALUES(?,?,?,?,?,?,?,?,?,'UNPAID',?)",(num,so["sales_order_id"],shid,date.today().isoformat(),(date.today()+timedelta(days=term)).isoformat(),c,amount,0,amount,user_ids["EMP004"]))
            invid=inv.lastrowid
            revenue_total=Decimal('0')
            for d in ds:
                line=(Decimal(str(d["quantity_shipped"]))*Decimal(str(d["unit_price"])))
                net=line*(Decimal('1')-Decimal(str(d["discount_percentage"]))/Decimal('100'))
                revenue_total+=net
                conn.execute("INSERT INTO invoice_details(invoice_id,shipping_detail_id,product_id,quantity_invoiced,unit_price,discount_percentage,tax_amount,line_amount) VALUES(?,?,?,?,?,?,?,?)",(invid,d["shipping_detail_id"],d["product_id"],d["quantity_shipped"],d["unit_price"],d["discount_percentage"],(net*Decimal('0.11')).quantize(Decimal('0.01')),net))
            pa=conn.execute("SELECT sales_account_id FROM product_accounts WHERE product_id=? LIMIT 1",(ds[0]["product_id"],)).fetchone()
            post_accounting_entry(conn,user_ids["EMP004"],"INVOICE",invid,f"Seed invoice {num}",[(coa_ids["1100"],amount,0,num),(pa["sales_account_id"],0,revenue_total,num),(coa_ids["2200"],0,tax,num)])
            update_invoice_status(conn,invid)
            return invid,amount

        # SO1: successful credit flow, fully shipped, paid in two receipts.
        so1,total1,c1=insert_so("SO-2026-000001","CUST-000001","EMP001","CREDIT","NET30",[("PROD-000001",5,15000000,0),("PROD-000003",2,6500000,0)],"READY FOR SHIPPING")
        ca1=conn.execute("INSERT INTO credit_approvals(approval_number,sales_order_id,customer_id,credit_limit,outstanding_balance,order_amount,available_credit,eligibility_result,decision,approved_by,approval_date,remarks) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",("CA-2026-000001",so1,c1,100000000,0,total1,100000000-money(total1),"ELIGIBLE","APPROVED",user_ids["EMP002"],date.today().isoformat(),"Eligible based on available credit."))
        conn.execute("UPDATE sales_orders SET order_status='FULLY SHIPPED' WHERE sales_order_id=?",(so1,))
        sh1=ship(so1,"SH-2026-000001",[("PROD-000001",5),("PROD-000003",2)])
        inv1,amt1=invoice_from_shipping(sh1,"INV-2026-000001")
        r1=conn.execute("INSERT INTO cash_receipts(receipt_number,invoice_id,receipt_date,amount,payment_method,bank_reference,received_by,remarks) VALUES(?,?,?,?,?,?,?,?)",("RC-2026-000001",inv1,date.today().isoformat(),10000000,"Bank Transfer","BANK-REC-001",user_ids["EMP005"],"First collection")); rid1=r1.lastrowid
        post_accounting_entry(conn,user_ids["EMP005"],"CASH_RECEIPT",rid1,"Seed receipt 1",[(coa_ids["1010"],10000000,0,"RC-2026-000001"),(coa_ids["1100"],0,10000000,"RC-2026-000001")])
        rem=money(amt1)-money(10000000)
        r2=conn.execute("INSERT INTO cash_receipts(receipt_number,invoice_id,receipt_date,amount,payment_method,bank_reference,received_by,remarks) VALUES(?,?,?,?,?,?,?,?)",("RC-2026-000002",inv1,date.today().isoformat(),rem,"Bank Transfer","BANK-REC-002",user_ids["EMP005"],"Final collection")); rid2=r2.lastrowid
        post_accounting_entry(conn,user_ids["EMP005"],"CASH_RECEIPT",rid2,"Seed receipt 2",[(coa_ids["1010"],rem,0,"RC-2026-000002"),(coa_ids["1100"],0,rem,"RC-2026-000002")])
        update_invoice_status(conn,inv1)

        # SO2: pending credit approval.
        so2,total2,c2=insert_so("SO-2026-000002","CUST-000003","EMP001","CREDIT","NET60",[("PROD-000005",2,12000000,0)],"PENDING CREDIT APPROVAL")
        conn.execute("INSERT INTO credit_approvals(approval_number,sales_order_id,customer_id,credit_limit,outstanding_balance,order_amount,available_credit,eligibility_result) VALUES(?,?,?,?,?,?,?,?)",("CA-2026-000002",so2,c2,75000000,0,total2,75000000-money(total2),"ELIGIBLE"))

        # Customer 2 has high AR to create a real credit rejection scenario.
        so_credit_base,total_base,cbase=insert_so("SO-2026-000003","CUST-000002","EMP001","CASH","CASH",[("PROD-000006",1,3800000,0)],"FULLY SHIPPED")
        sh_base=ship(so_credit_base,"SH-2026-000002",[("PROD-000006",1)])
        inv_base,amt_base=invoice_from_shipping(sh_base,"INV-2026-000002")
        # Inflate demo receivable with a separate invoice of ~45m for the same customer.
        so_credit_base2,total_base2,_=insert_so("SO-2026-000004","CUST-000002","EMP001","CASH","CASH",[("PROD-000002",2,17500000,0)],"FULLY SHIPPED")
        sh_base2=ship(so_credit_base2,"SH-2026-000003",[("PROD-000002",2)])
        inv_base2,amt_base2=invoice_from_shipping(sh_base2,"INV-2026-000003")
        # SO3 rejection after current outstanding is around 39m; order about 17m => insufficient.
        so3,total3,c3=insert_so("SO-2026-000005","CUST-000002","EMP001","CREDIT","NET30",[("PROD-000003",2,6500000,0)],"PENDING CREDIT APPROVAL")
        outstanding3=money(amt_base)+money(amt_base2)
        limit3=money(50000000); avail3=limit3-outstanding3
        conn.execute("INSERT INTO credit_approvals(approval_number,sales_order_id,customer_id,credit_limit,outstanding_balance,order_amount,available_credit,eligibility_result,decision,approved_by,approval_date,remarks) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",("CA-2026-000003",so3,c3,limit3,outstanding3,total3,avail3,"NOT ELIGIBLE","REJECTED",user_ids["EMP002"],date.today().isoformat(),"Credit approval rejected because available credit is insufficient."))
        conn.execute("UPDATE sales_orders SET order_status='REJECTED' WHERE sales_order_id=?",(so3,))

        # SO4: multiple-product partial shipment + partial invoice.
        so4,total4,c4=insert_so("SO-2026-000006","CUST-000001","EMP001","CREDIT","NET30",[("PROD-000001",5,15000000,0),("PROD-000003",3,6500000,0),("PROD-000005",1,12000000,0)],"READY FOR SHIPPING")
        conn.execute("INSERT INTO credit_approvals(approval_number,sales_order_id,customer_id,credit_limit,outstanding_balance,order_amount,available_credit,eligibility_result,decision,approved_by,approval_date,remarks) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",("CA-2026-000004",so4,c4,100000000,0,total4,100000000-money(total4),"ELIGIBLE","APPROVED",user_ids["EMP002"],date.today().isoformat(),"Eligible demo scenario."))
        sh4=ship(so4,"SH-2026-000004",[("PROD-000001",5),("PROD-000003",1)],"WH-B")
        inv4,amt4=invoice_from_shipping(sh4,"INV-2026-000004")
        r4=conn.execute("INSERT INTO cash_receipts(receipt_number,invoice_id,receipt_date,amount,payment_method,bank_reference,received_by,remarks) VALUES(?,?,?,?,?,?,?,?)",("RC-2026-000003",inv4,date.today().isoformat(),5000000,"Bank Transfer","BANK-REC-003",user_ids["EMP005"],"Partial collection")); rid4=r4.lastrowid
        post_accounting_entry(conn,user_ids["EMP005"],"CASH_RECEIPT",rid4,"Seed partial receipt",[(coa_ids["1010"],5000000,0,"RC-2026-000003"),(coa_ids["1100"],0,5000000,"RC-2026-000003")])
        update_invoice_status(conn,inv4)
        conn.execute("UPDATE sales_orders SET order_status='PARTIALLY SHIPPED' WHERE sales_order_id=?",(so4,))
        # Second shipment remains optional/manual and can be created by warehouse for remaining lines.

        # SO5: cash order ready for shipping.
        so5,total5,c5=insert_so("SO-2026-000007","CUST-000004","EMP001","CASH","CASH",[("PROD-000006",4,3800000,0)],"READY FOR SHIPPING")

        # SO6: stock-shortage scenario: order 10 laptops while current aggregate is 10-ish after seed shipments.
        so6,total6,c6=insert_so("SO-2026-000008","CUST-000005","EMP001","CASH","CASH",[("PROD-000001",10,15000000,0)],"READY FOR SHIPPING")

        # SO7: discount approval scenario.
        so7,total7,c7=insert_so("SO-2026-000009","CUST-000003","EMP001","CREDIT","NET60",[("PROD-000006",5,3800000,15)],"DRAFT")
        conn.execute("UPDATE sales_orders SET discount_approval_required=1,discount_approval_status='PENDING' WHERE sales_order_id=?",(so7,))
        conn.execute("INSERT INTO manager_approvals(entity_type,entity_id,requested_discount,maximum_allowed_discount,approval_status) VALUES('SALES_ORDER',?,?,?,'PENDING')",(so7,15,10))

        # Inventory currently reflects the opening stock less all seeded shipments; refresh cache.
        for pid in prod_ids.values():
            qty=conn.execute("SELECT COALESCE(SUM(quantity),0) q FROM inventory_stock WHERE product_id=?",(pid,)).fetchone()["q"]
            conn.execute("UPDATE products SET available_stock=? WHERE product_id=?",(qty,pid))

        # Bank reconciliation data: one matched, one unmatched, one mismatched exception.
        conn.execute("INSERT INTO bank_transactions(transaction_date,amount,transaction_type,reference,description) VALUES(?,?,?,?,?)",(date.today().isoformat(),10000000,"INCOMING","BANK-REC-001","Incoming collection for RC-2026-000001"))
        bt1=conn.execute("SELECT last_insert_rowid() x").fetchone()["x"]
        conn.execute("INSERT INTO bank_reconciliations(bank_transaction_id,cash_receipt_id,reconciliation_status,difference_amount,reconciled_by,reconciled_at) VALUES(?,?, 'RECONCILED',0,?,?)",(bt1,rid1,user_ids["EMP004"],date.today().isoformat()))
        conn.execute("INSERT INTO bank_transactions(transaction_date,amount,transaction_type,reference,description) VALUES(?,?,?,?,?)",(date.today().isoformat(),3000000,"INCOMING","BANK-UNMATCHED-001","No matching system receipt"))
        bt2=conn.execute("SELECT last_insert_rowid() x").fetchone()["x"]
        conn.execute("INSERT INTO bank_reconciliations(bank_transaction_id,reconciliation_status) VALUES(?,'UNRECONCILED')",(bt2,))
        conn.execute("INSERT INTO bank_transactions(transaction_date,amount,transaction_type,reference,description) VALUES(?,?,?,?,?)",(date.today().isoformat(),7000000,"INCOMING","BANK-EXC-001","Amount differs from receipt RC-2026-000003"))
        bt3=conn.execute("SELECT last_insert_rowid() x").fetchone()["x"]
        conn.execute("INSERT INTO bank_reconciliations(bank_transaction_id,cash_receipt_id,reconciliation_status,difference_amount,reason) VALUES(?,?, 'EXCEPTION',2000000,'Amount mismatch requires investigation.')",(bt3,rid4))

        # Seed notifications routed to responsible roles.
        add_notification(user_ids["EMP002"],"Sales Order SO-2026-000002 requires credit approval.","CREDIT_APPROVAL",so2,conn)
        add_notification(user_ids["EMP003"],"Sales Order SO-2026-000006 is ready for the next shipment.","SALES_ORDER",so4,conn)
        add_notification(user_ids["EMP004"],"Shipping SH-2026-000004 has been confirmed. Invoice is available.","SHIPPING",sh4,conn)
        add_notification(user_ids["EMP005"],"Invoice INV-2026-000004 has been issued and has an outstanding balance.","INVOICE",inv4,conn)
        add_notification(user_ids["EMP001"],"Credit approval rejected for SO-2026-000005 because available credit is insufficient.","SALES_ORDER",so3,conn)
        add_notification(user_ids["EMP006"],"Sales Order SO-2026-000009 requires manager discount approval.","SALES_ORDER",so7,conn)

        # Seed audit entries for major demo events.
        demo_user=next(r for r in conn.execute("SELECT u.*,r.role_name FROM users u JOIN roles r ON r.role_id=u.role_id WHERE u.employee_id='EMP007'"))
        for action,module,rid in [
            ("SEED DATA LOADED","SYSTEM",None),("SALES ORDER CREATED","SALES_ORDER",so1),("CREDIT APPROVED","CREDIT_APPROVAL",ca1.lastrowid),("SHIPPING CONFIRMED","SHIPPING",sh1),("INVOICE ISSUED","INVOICE",inv1),("CASH RECEIPT CREATED","CASH_RECEIPT",rid1),("CASH RECEIPT CREATED","CASH_RECEIPT",rid2),("CREDIT REJECTED","CREDIT_APPROVAL",3),("SHIPPING CONFIRMED","SHIPPING",sh4),("INVOICE ISSUED","INVOICE",inv4),("CASH RECEIPT CREATED","CASH_RECEIPT",rid4),("BANK RECONCILIATION","BANK_RECONCILIATION",bt1),("BANK EXCEPTION","BANK_RECONCILIATION",bt3),
        ]:
            add_audit(demo_user,action,module,rid,conn=conn)
        conn.commit()
        print("Seed complete:", DB_PATH)
    finally:
        conn.close()


if __name__ == "__main__":
    seed()
