import unittest
import sys
from decimal import Decimal
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))
from security import check_password, hash_password
from services import calculate_order, require_transition, STATUS_TRANSITIONS

class CoreLogicTests(unittest.TestCase):
    def test_password_hash_roundtrip(self):
        stored = hash_password("Demo@123")
        self.assertTrue(check_password(stored, "Demo@123"))
        self.assertFalse(check_password(stored, "Wrong@123"))
        self.assertNotEqual(stored, "Demo@123")

    def test_order_calculation(self):
        lines = [{"product_id":1,"quantity":2,"unit_price":Decimal("15000000"),"discount_percentage":Decimal("5")},
                 {"product_id":2,"quantity":1,"unit_price":Decimal("6500000"),"discount_percentage":Decimal("0")}]
        normalized, subtotal, discount, tax, total, max_discount = calculate_order(lines, Decimal("100000"))
        self.assertEqual(subtotal, Decimal("36500000.00"))
        self.assertEqual(discount, Decimal("1500000.00"))
        self.assertEqual(tax, Decimal("3850000.00"))
        self.assertEqual(total, Decimal("38950000.00"))
        self.assertEqual(max_discount, Decimal("5.00"))

    def test_zero_quantity_is_rejected(self):
        with self.assertRaises(ValueError):
            calculate_order([{"product_id":1,"quantity":0,"unit_price":100,"discount_percentage":0}],0)

    def test_negative_price_is_rejected(self):
        with self.assertRaises(ValueError):
            calculate_order([{"product_id":1,"quantity":1,"unit_price":-1,"discount_percentage":0}],0)

    def test_discount_bounds(self):
        with self.assertRaises(ValueError):
            calculate_order([{"product_id":1,"quantity":1,"unit_price":100,"discount_percentage":101}],0)

    def test_valid_status_transition(self):
        require_transition("DRAFT","SUBMITTED")
        require_transition("SUBMITTED","PENDING CREDIT APPROVAL")
        require_transition("READY FOR SHIPPING","PARTIALLY SHIPPED")
        require_transition("PARTIALLY SHIPPED","FULLY SHIPPED")

    def test_invalid_status_jump(self):
        with self.assertRaises(ValueError):
            require_transition("DRAFT","FULLY SHIPPED")
        with self.assertRaises(ValueError):
            require_transition("PENDING CREDIT APPROVAL","FULLY SHIPPED")

    def test_transition_map_contains_required_states(self):
        for state in ["DRAFT","SUBMITTED","PENDING CREDIT APPROVAL","REJECTED","READY FOR SHIPPING","PARTIALLY SHIPPED","FULLY SHIPPED"]:
            self.assertIn(state, STATUS_TRANSITIONS)

if __name__ == "__main__":
    unittest.main()
