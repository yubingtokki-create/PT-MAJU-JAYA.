import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from security import check_password
DB = ROOT / "maju_jaya.db"
REQUIRED = [
    "users","roles","permissions","role_permissions","customers","products","product_accounts","payment_terms",
    "sales_orders","sales_order_details","credit_approvals","shippings","shipping_details","invoices","cash_receipts",
    "bank_transactions","bank_reconciliations","audit_logs","notifications","inventory_stock","inventory_movements",
    "manager_approvals","chart_of_accounts","invoice_details","warehouses","goods_receipts","stock_transfers","inventory_adjustments",
]

conn = sqlite3.connect(DB)
conn.row_factory = sqlite3.Row
try:
    tables = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    missing = [x for x in REQUIRED if x not in tables]
    assert not missing, f"Missing tables: {missing}"
    assert conn.execute("PRAGMA foreign_key_check").fetchall() == []
    assert conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"] == 7
    assert conn.execute("SELECT COUNT(*) c FROM products").fetchone()["c"] >= 6
    assert conn.execute("SELECT COUNT(*) c FROM customers").fetchone()["c"] >= 5
    assert conn.execute("SELECT COUNT(*) c FROM sales_order_details").fetchone()["c"] >= 10
    assert conn.execute("SELECT COUNT(*) c FROM credit_approvals").fetchone()["c"] >= 2
    assert conn.execute("SELECT COUNT(*) c FROM shippings").fetchone()["c"] >= 2
    assert conn.execute("SELECT COUNT(*) c FROM invoices WHERE invoice_status='PAID'").fetchone()["c"] >= 1
    assert conn.execute("SELECT COUNT(*) c FROM invoices WHERE invoice_status='PARTIAL'").fetchone()["c"] >= 1
    assert conn.execute("SELECT COUNT(*) c FROM invoices WHERE invoice_status='UNPAID'").fetchone()["c"] >= 1
    assert conn.execute("SELECT COUNT(*) c FROM bank_reconciliations WHERE reconciliation_status='RECONCILED'").fetchone()["c"] >= 1
    assert conn.execute("SELECT COUNT(*) c FROM bank_reconciliations WHERE reconciliation_status='UNRECONCILED'").fetchone()["c"] >= 1
    assert conn.execute("SELECT COUNT(*) c FROM bank_reconciliations WHERE reconciliation_status='EXCEPTION'").fetchone()["c"] >= 1
    assert conn.execute("SELECT COUNT(*) c FROM manager_approvals WHERE approval_status='PENDING'").fetchone()["c"] >= 1
    for row in conn.execute("SELECT employee_id,password_hash FROM users"):
        passwords = {
            "EMP001":"Sales@123","EMP002":"Credit@123","EMP003":"Warehouse@123","EMP004":"Account@123",
            "EMP005":"Cashier@123","EMP006":"Manager@123","EMP007":"Admin@123"}
        assert check_password(row["password_hash"], passwords[row["employee_id"]])
    assert conn.execute("SELECT COUNT(*) c FROM products WHERE available_stock < 0").fetchone()["c"] == 0
    print("SMOKE PASS: schema, FK integrity, demo data coverage, password hashes and non-negative inventory verified.")
finally:
    conn.close()
