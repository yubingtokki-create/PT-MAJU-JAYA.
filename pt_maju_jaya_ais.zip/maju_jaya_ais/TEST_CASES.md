# PT Maju Jaya AIS — Test Cases

Format: Test ID | Scenario | Input | Expected Result | Actual Result | PASS/FAIL

The 50 cases below combine the required core controls and the updated exception/partial-processing requirements.

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|---|---|---|---|---|---|
| 01 | Valid customer SO | Active customer + valid line | SO created | Verify in UI | Pending execution |
| 02 | Inactive customer | Customer status INACTIVE | New SO blocked | Verify in UI | Pending execution |
| 03 | Inactive product | Product status INACTIVE | Product line blocked server-side | Verify in UI/API | Pending execution |
| 04 | Quantity zero | Qty 0 | Blocked | Service logic covered | PASS |
| 05 | Negative quantity | Qty -1 | Blocked | Service logic covered | PASS |
| 06 | Insufficient stock shipping | Ship > location stock | Shipment blocked; no stock reduction | Verify UI | Pending execution |
| 07 | Sufficient stock shipping | Ship <= stock and remaining | Shipment confirmed | Verify UI | Pending execution |
| 08 | Credit SO | CREDIT sales | Credit approval required | Seed + route logic | PASS (design/seed) |
| 09 | Sufficient credit | Available >= order | Eligible/approval can proceed | Verify UI | Pending execution |
| 10 | Insufficient credit | Available < order | Rejected and shipping blocked | Seeded rejection scenario | PASS |
| 11 | Shipping while credit pending | SO pending approval | Blocked | Verify UI | Pending execution |
| 12 | Shipping after rejected credit | Rejected SO | Blocked | Verify UI | Pending execution |
| 13 | Shipping after approval | Approved credit SO | Shipping available | Seeded + verify | PASS (seed) |
| 14 | Partial shipment | Ship less than remaining | PARTIALLY SHIPPED | Seeded multi-line partial | PASS |
| 15 | Ship > ordered | Requested > remaining | Blocked | Verify UI/API | Pending execution |
| 16 | Invoice without shipping | No confirmed shipment | Blocked | Route rule | PASS (design) |
| 17 | Valid invoice | Confirmed shipment | Invoice created | Verify UI | Pending execution |
| 18 | Partial payment | Payment < outstanding | Invoice PARTIAL | Seeded | PASS |
| 19 | Full payment | Payment brings balance to 0 | Invoice PAID | Seeded | PASS |
| 20 | Payment > outstanding | Amount exceeds balance | Blocked | Route rule | PASS (design) |
| 21 | Salesperson self-approval | EMP001 approves own SO | Blocked | Backend rule | PASS (design) |
| 22 | Unauthorized page | Credit URL as Cashier | ACCESS DENIED | Backend permission | PASS (design) |
| 23 | Invoice source integrity | Invoice from actual shipping | Data matches SO/shipping | Verify UI | Pending execution |
| 24 | Bank match | Bank amount = receipt | RECONCILED | Seeded | PASS |
| 25 | Unmatched bank | No matching receipt | UNRECONCILED | Seeded | PASS |
| 26 | Excessive discount | Discount 15% | Manager approval required | Seeded | PASS |
| 27 | Invalid OTP | Wrong verification code | Blocked | Verify UI | Pending execution |
| 28 | Expired OTP | Expired code | Blocked | Verify UI | Pending execution |
| 29 | Duplicate document | Reuse same document number | DB/backend blocks | UNIQUE constraints | PASS |
| 30 | Audit after action | Successful transaction | Audit record created | Seeded | PASS |
| 31 | Unauthorized direct URL | Restricted URL without permission | Access denied | Backend decorator | PASS (design) |
| 32 | Unauthorized POST/API | Restricted POST with wrong role | Blocked | Backend decorator | PASS (design) |
| 33 | Inventory adjustment | Physical != system | Stock updates + audit | Service route | Pending execution |
| 34 | Stock transfer | Source to destination | Source decreases, destination increases | Service route | Pending execution |
| 35 | Inactive product crafted request | POST inactive product ID | Backend rejects | `validate_product_active` | PASS (design) |
| 36 | Multiple products in SO | Laptop + printer + projector | All lines saved separately | Seeded | PASS |
| 37 | Partial shipment by line | Laptop 5, printer 1 | Per-line remaining qty accurate | Seeded | PASS |
| 38 | Multiple shipments per SO | Shipment 1 + Shipment 2 | Both tied to same SO | Schema supports | Pending execution |
| 39 | Ship above remaining | Remaining 2, request 3 | Blocked | Backend rule | PASS (design) |
| 40 | Rejected credit traceability | Rejected CA | SO and rejection remain visible | Seeded | PASS |
| 41 | Rejected credit cannot ship | REJECTED SO | Shipping blocked | Backend rule | PASS (design) |
| 42 | Revised/resubmitted order | REJECTED → revision | New Draft with revision reference | Route implemented | Pending execution |
| 43 | Partial billing | Partial shipment | Invoice only shipped lines | Seeded / route | PASS (design) |
| 44 | Duplicate billing | Same shipping twice | Second invoice blocked | UNIQUE(shipping_id) | PASS |
| 45 | Invalid payment leaves balance | Overpayment attempt | No receipt; invoice unchanged | Transaction rollback | PASS (design) |
| 46 | Cancelled shipment billing | Cancelled shipping | Cannot generate normal invoice | Backend rule | PASS (design) |
| 47 | Unreconciled bank remains visible | Bank-only transaction | UNRECONCILED | Seeded | PASS |
| 48 | Mismatched bank | Bank 7m vs receipt 5m | EXCEPTION + difference | Seeded | PASS |
| 49 | Unauthorized adjustment | Non-warehouse user | Blocked | Permission decorator | PASS (design) |
| 50 | Blocked action audit | Invalid critical action | Audit log records BLOCKED and reason | `log_block`/audit route | PASS (design) |

## Automated checks available

`python tests/smoke_sqlite.py` checks schema completeness, FK integrity, demo data coverage, password hashes and non-negative inventory.

`python -m unittest tests/test_core_logic.py` checks password hashing, order calculations, validation bounds and workflow transition control.

The Flask UI integration cases can be exercised after installing the single project dependency from `requirements.txt`.
