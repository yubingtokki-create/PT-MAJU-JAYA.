PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS roles (
    role_id INTEGER PRIMARY KEY AUTOINCREMENT,
    role_name TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS permissions (
    permission_id INTEGER PRIMARY KEY AUTOINCREMENT,
    permission_code TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id INTEGER NOT NULL,
    permission_id INTEGER NOT NULL,
    PRIMARY KEY (role_id, permission_id),
    FOREIGN KEY (role_id) REFERENCES roles(role_id),
    FOREIGN KEY (permission_id) REFERENCES permissions(permission_id)
);

CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id TEXT NOT NULL UNIQUE,
    employee_name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role_id INTEGER NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    failed_login_count INTEGER NOT NULL DEFAULT 0,
    last_login_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

CREATE TABLE IF NOT EXISTS payment_terms (
    payment_term_id INTEGER PRIMARY KEY AUTOINCREMENT,
    term_code TEXT NOT NULL UNIQUE,
    term_name TEXT NOT NULL,
    days INTEGER NOT NULL CHECK (days >= 0)
);

CREATE TABLE IF NOT EXISTS customers (
    customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_code TEXT NOT NULL UNIQUE,
    customer_name TEXT NOT NULL,
    customer_type TEXT NOT NULL,
    npwp TEXT,
    contact_person TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT NOT NULL,
    email_verified INTEGER NOT NULL DEFAULT 0 CHECK (email_verified IN (0,1)),
    verification_code_hash TEXT,
    verification_expires_at TEXT,
    billing_address TEXT NOT NULL,
    delivery_address TEXT NOT NULL,
    city TEXT NOT NULL,
    province TEXT NOT NULL,
    postal_code TEXT NOT NULL,
    credit_limit NUMERIC NOT NULL DEFAULT 0 CHECK (credit_limit >= 0),
    payment_term_id INTEGER NOT NULL,
    customer_status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (customer_status IN ('ACTIVE','INACTIVE')),
    created_by INTEGER,
    created_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_term_id) REFERENCES payment_terms(payment_term_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS chart_of_accounts (
    account_id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_code TEXT NOT NULL UNIQUE,
    account_name TEXT NOT NULL,
    account_type TEXT NOT NULL CHECK (account_type IN ('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE'))
);

CREATE TABLE IF NOT EXISTS products (
    product_id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_code TEXT NOT NULL UNIQUE,
    product_name TEXT NOT NULL,
    category TEXT NOT NULL,
    brand TEXT NOT NULL,
    description TEXT,
    unit TEXT NOT NULL,
    selling_price NUMERIC NOT NULL CHECK (selling_price >= 0),
    available_stock NUMERIC NOT NULL DEFAULT 0 CHECK (available_stock >= 0),
    standard_cost NUMERIC NOT NULL DEFAULT 0 CHECK (standard_cost >= 0),
    product_status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (product_status IN ('ACTIVE','INACTIVE')),
    created_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS product_accounts (
    product_account_id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL UNIQUE,
    inventory_account_id INTEGER NOT NULL,
    sales_account_id INTEGER NOT NULL,
    cogs_account_id INTEGER NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (inventory_account_id) REFERENCES chart_of_accounts(account_id),
    FOREIGN KEY (sales_account_id) REFERENCES chart_of_accounts(account_id),
    FOREIGN KEY (cogs_account_id) REFERENCES chart_of_accounts(account_id)
);

CREATE TABLE IF NOT EXISTS warehouses (
    warehouse_id INTEGER PRIMARY KEY AUTOINCREMENT,
    warehouse_code TEXT NOT NULL UNIQUE,
    warehouse_name TEXT NOT NULL,
    address TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);

CREATE TABLE IF NOT EXISTS inventory_stock (
    inventory_stock_id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL,
    warehouse_id INTEGER NOT NULL,
    quantity NUMERIC NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    UNIQUE(product_id, warehouse_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id)
);

CREATE TABLE IF NOT EXISTS sales_orders (
    sales_order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    so_number TEXT NOT NULL UNIQUE,
    order_date TEXT NOT NULL,
    customer_id INTEGER NOT NULL,
    salesperson_id INTEGER NOT NULL,
    sales_type TEXT NOT NULL CHECK (sales_type IN ('CASH','CREDIT')),
    payment_term_id INTEGER NOT NULL,
    delivery_date TEXT NOT NULL,
    delivery_address TEXT NOT NULL,
    shipping_cost NUMERIC NOT NULL DEFAULT 0 CHECK (shipping_cost >= 0),
    tax NUMERIC NOT NULL DEFAULT 0 CHECK (tax >= 0),
    subtotal NUMERIC NOT NULL DEFAULT 0 CHECK (subtotal >= 0),
    discount NUMERIC NOT NULL DEFAULT 0 CHECK (discount >= 0),
    grand_total NUMERIC NOT NULL DEFAULT 0 CHECK (grand_total >= 0),
    order_status TEXT NOT NULL DEFAULT 'DRAFT',
    customer_notes TEXT,
    internal_notes TEXT,
    discount_approval_required INTEGER NOT NULL DEFAULT 0 CHECK (discount_approval_required IN (0,1)),
    discount_approval_status TEXT NOT NULL DEFAULT 'NOT_REQUIRED' CHECK (discount_approval_status IN ('NOT_REQUIRED','PENDING','APPROVED','REJECTED')),
    revision_of_id INTEGER,
    created_by INTEGER NOT NULL,
    created_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (salesperson_id) REFERENCES users(user_id),
    FOREIGN KEY (payment_term_id) REFERENCES payment_terms(payment_term_id),
    FOREIGN KEY (revision_of_id) REFERENCES sales_orders(sales_order_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS sales_order_details (
    sales_order_detail_id INTEGER PRIMARY KEY AUTOINCREMENT,
    sales_order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity NUMERIC NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC NOT NULL CHECK (unit_price >= 0),
    discount_percentage NUMERIC NOT NULL DEFAULT 0 CHECK (discount_percentage >= 0 AND discount_percentage <= 100),
    discount_amount NUMERIC NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
    line_subtotal NUMERIC NOT NULL DEFAULT 0 CHECK (line_subtotal >= 0),
    UNIQUE(sales_order_id, product_id),
    FOREIGN KEY (sales_order_id) REFERENCES sales_orders(sales_order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE IF NOT EXISTS manager_approvals (
    manager_approval_id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,
    entity_id INTEGER NOT NULL,
    requested_discount NUMERIC NOT NULL DEFAULT 0,
    maximum_allowed_discount NUMERIC NOT NULL DEFAULT 10,
    approval_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (approval_status IN ('PENDING','APPROVED','REJECTED')),
    approved_by INTEGER,
    approval_date TEXT,
    remarks TEXT,
    UNIQUE(entity_type, entity_id),
    FOREIGN KEY (approved_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS credit_approvals (
    credit_approval_id INTEGER PRIMARY KEY AUTOINCREMENT,
    approval_number TEXT NOT NULL UNIQUE,
    sales_order_id INTEGER NOT NULL UNIQUE,
    customer_id INTEGER NOT NULL,
    credit_limit NUMERIC NOT NULL,
    outstanding_balance NUMERIC NOT NULL,
    order_amount NUMERIC NOT NULL,
    available_credit NUMERIC NOT NULL,
    eligibility_result TEXT NOT NULL CHECK (eligibility_result IN ('ELIGIBLE','NOT ELIGIBLE')),
    decision TEXT CHECK (decision IN ('APPROVED','REJECTED')),
    approved_by INTEGER,
    approval_date TEXT,
    remarks TEXT,
    FOREIGN KEY (sales_order_id) REFERENCES sales_orders(sales_order_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (approved_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS shippings (
    shipping_id INTEGER PRIMARY KEY AUTOINCREMENT,
    shipping_number TEXT NOT NULL UNIQUE,
    sales_order_id INTEGER NOT NULL,
    shipping_date TEXT NOT NULL,
    delivery_address TEXT NOT NULL,
    shipping_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (shipping_status IN ('PENDING','SHIPPED','CANCELLED')),
    shipped_by INTEGER NOT NULL,
    created_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sales_order_id) REFERENCES sales_orders(sales_order_id),
    FOREIGN KEY (shipped_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS shipping_details (
    shipping_detail_id INTEGER PRIMARY KEY AUTOINCREMENT,
    shipping_id INTEGER NOT NULL,
    sales_order_detail_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity_shipped NUMERIC NOT NULL CHECK (quantity_shipped > 0),
    unit_cost NUMERIC NOT NULL DEFAULT 0 CHECK (unit_cost >= 0),
    warehouse_id INTEGER NOT NULL,
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (shipping_id) REFERENCES shippings(shipping_id),
    FOREIGN KEY (sales_order_detail_id) REFERENCES sales_order_details(sales_order_detail_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE IF NOT EXISTS invoices (
    invoice_id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_number TEXT NOT NULL UNIQUE,
    sales_order_id INTEGER NOT NULL,
    shipping_id INTEGER NOT NULL,
    invoice_date TEXT NOT NULL,
    due_date TEXT NOT NULL,
    customer_id INTEGER NOT NULL,
    invoice_amount NUMERIC NOT NULL CHECK (invoice_amount >= 0),
    paid_amount NUMERIC NOT NULL DEFAULT 0 CHECK (paid_amount >= 0),
    outstanding_amount NUMERIC NOT NULL DEFAULT 0 CHECK (outstanding_amount >= 0),
    invoice_status TEXT NOT NULL DEFAULT 'UNPAID' CHECK (invoice_status IN ('UNPAID','PARTIAL','PAID','CANCELLED')),
    created_by INTEGER NOT NULL,
    created_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sales_order_id) REFERENCES sales_orders(sales_order_id),
    FOREIGN KEY (shipping_id) REFERENCES shippings(shipping_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    UNIQUE(shipping_id)
);

CREATE TABLE IF NOT EXISTS invoice_details (
    invoice_detail_id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL,
    shipping_detail_id INTEGER NOT NULL UNIQUE,
    product_id INTEGER NOT NULL,
    quantity_invoiced NUMERIC NOT NULL CHECK (quantity_invoiced > 0),
    unit_price NUMERIC NOT NULL CHECK (unit_price >= 0),
    discount_percentage NUMERIC NOT NULL DEFAULT 0 CHECK (discount_percentage >= 0),
    tax_amount NUMERIC NOT NULL DEFAULT 0 CHECK (tax_amount >= 0),
    line_amount NUMERIC NOT NULL CHECK (line_amount >= 0),
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id),
    FOREIGN KEY (shipping_detail_id) REFERENCES shipping_details(shipping_detail_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE IF NOT EXISTS cash_receipts (
    receipt_id INTEGER PRIMARY KEY AUTOINCREMENT,
    receipt_number TEXT NOT NULL UNIQUE,
    invoice_id INTEGER NOT NULL,
    receipt_date TEXT NOT NULL,
    amount NUMERIC NOT NULL CHECK (amount > 0),
    payment_method TEXT NOT NULL CHECK (payment_method IN ('Cash','Bank Transfer','Credit Card','Cheque','Giro')),
    bank_reference TEXT,
    received_by INTEGER NOT NULL,
    remarks TEXT,
    created_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'POSTED' CHECK (status IN ('POSTED','REVERSED')),
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id),
    FOREIGN KEY (received_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS bank_transactions (
    bank_transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_date TEXT NOT NULL,
    amount NUMERIC NOT NULL CHECK (amount > 0),
    transaction_type TEXT NOT NULL CHECK (transaction_type IN ('INCOMING','OUTGOING')),
    reference TEXT,
    description TEXT,
    created_date TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bank_reconciliations (
    reconciliation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    bank_transaction_id INTEGER NOT NULL UNIQUE,
    cash_receipt_id INTEGER,
    reconciliation_status TEXT NOT NULL DEFAULT 'UNRECONCILED' CHECK (reconciliation_status IN ('UNRECONCILED','RECONCILED','EXCEPTION','ADJUSTED')),
    difference_amount NUMERIC NOT NULL DEFAULT 0,
    reconciled_by INTEGER,
    reconciled_at TEXT,
    reason TEXT,
    FOREIGN KEY (bank_transaction_id) REFERENCES bank_transactions(bank_transaction_id),
    FOREIGN KEY (cash_receipt_id) REFERENCES cash_receipts(receipt_id),
    FOREIGN KEY (reconciled_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS inventory_movements (
    movement_id INTEGER PRIMARY KEY AUTOINCREMENT,
    movement_number TEXT NOT NULL UNIQUE,
    product_id INTEGER NOT NULL,
    warehouse_id INTEGER NOT NULL,
    movement_type TEXT NOT NULL CHECK (movement_type IN ('OPENING','RECEIPT','SHIPMENT','TRANSFER_OUT','TRANSFER_IN','ADJUSTMENT')),
    quantity_change NUMERIC NOT NULL,
    reference_type TEXT,
    reference_id INTEGER,
    reason TEXT,
    unit_cost NUMERIC NOT NULL DEFAULT 0,
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS goods_receipts (
    grn_id INTEGER PRIMARY KEY AUTOINCREMENT,
    grn_number TEXT NOT NULL UNIQUE,
    receiving_date TEXT NOT NULL,
    reference_purchase_order TEXT,
    product_id INTEGER NOT NULL,
    quantity_received NUMERIC NOT NULL CHECK (quantity_received > 0),
    warehouse_id INTEGER NOT NULL,
    unit_cost NUMERIC NOT NULL DEFAULT 0 CHECK (unit_cost >= 0),
    status TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','CONFIRMED','CANCELLED')),
    received_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (received_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS stock_transfers (
    transfer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    transfer_number TEXT NOT NULL UNIQUE,
    product_id INTEGER NOT NULL,
    quantity NUMERIC NOT NULL CHECK (quantity > 0),
    source_warehouse_id INTEGER NOT NULL,
    destination_warehouse_id INTEGER NOT NULL,
    transfer_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'COMPLETED' CHECK (status IN ('PENDING','COMPLETED','CANCELLED')),
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (source_warehouse_id <> destination_warehouse_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (source_warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (destination_warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS inventory_adjustments (
    adjustment_id INTEGER PRIMARY KEY AUTOINCREMENT,
    adjustment_number TEXT NOT NULL UNIQUE,
    product_id INTEGER NOT NULL,
    warehouse_id INTEGER NOT NULL,
    system_quantity NUMERIC NOT NULL CHECK (system_quantity >= 0),
    physical_quantity NUMERIC NOT NULL CHECK (physical_quantity >= 0),
    adjustment_quantity NUMERIC NOT NULL,
    reason TEXT NOT NULL,
    adjusted_by INTEGER NOT NULL,
    adjustment_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'POSTED' CHECK (status IN ('POSTED','CANCELLED')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (adjusted_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS accounting_entries (
    entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_number TEXT NOT NULL UNIQUE,
    entry_date TEXT NOT NULL,
    source_type TEXT NOT NULL,
    source_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS accounting_entry_lines (
    entry_line_id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_id INTEGER NOT NULL,
    account_id INTEGER NOT NULL,
    debit NUMERIC NOT NULL DEFAULT 0 CHECK (debit >= 0),
    credit NUMERIC NOT NULL DEFAULT 0 CHECK (credit >= 0),
    reference_text TEXT,
    FOREIGN KEY (entry_id) REFERENCES accounting_entries(entry_id),
    FOREIGN KEY (account_id) REFERENCES chart_of_accounts(account_id),
    CHECK ((debit > 0 AND credit = 0) OR (credit > 0 AND debit = 0))
);

CREATE TABLE IF NOT EXISTS credit_notes (
    credit_note_id INTEGER PRIMARY KEY AUTOINCREMENT,
    credit_note_number TEXT NOT NULL UNIQUE,
    customer_id INTEGER NOT NULL,
    invoice_id INTEGER,
    amount NUMERIC NOT NULL CHECK (amount > 0),
    applied_amount NUMERIC NOT NULL DEFAULT 0 CHECK (applied_amount >= 0),
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','APPLIED','CANCELLED')),
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER,
    user_role TEXT,
    action TEXT NOT NULL,
    module TEXT NOT NULL,
    record_id TEXT,
    old_value TEXT,
    new_value TEXT,
    ip_address TEXT,
    session_id TEXT,
    result TEXT NOT NULL DEFAULT 'SUCCESS' CHECK (result IN ('SUCCESS','BLOCKED','FAILED')),
    reason TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS notifications (
    notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    message TEXT NOT NULL,
    module TEXT NOT NULL,
    record_id INTEGER,
    is_read INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0,1)),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE INDEX IF NOT EXISTS idx_so_customer ON sales_orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_so_status ON sales_orders(order_status);
CREATE INDEX IF NOT EXISTS idx_so_salesperson ON sales_orders(salesperson_id);
CREATE INDEX IF NOT EXISTS idx_receipt_invoice ON cash_receipts(invoice_id);
CREATE INDEX IF NOT EXISTS idx_shipping_so ON shippings(sales_order_id);
CREATE INDEX IF NOT EXISTS idx_audit_module_record ON audit_logs(module, record_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_stock_product ON inventory_stock(product_id);
