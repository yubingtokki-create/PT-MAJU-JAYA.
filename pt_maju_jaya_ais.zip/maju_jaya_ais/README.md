# PT Maju Jaya — Integrated Accounting Information System (AIS)

A university-level Flask + SQLite prototype for a trading company. The project is intentionally simple to understand technically, but the business flow is integrated and enforces realistic controls rather than behaving like unrelated CRUD pages.

The project follows the supplied master prompt and its update: realistic transaction states, exceptions, partial processing, rejection, controlled revision/resubmission, inventory shortages, payment exceptions, accounting integration, bank reconciliation, notifications, and auditable blocked actions are supported.

## 1. Architecture

**Authentication Layer** → login/session/password hashing.

**Authorization / RBAC Layer** → roles and database-driven permissions; restricted routes and POST actions are enforced server-side.

**Master Data Layer** → customers, products, payment terms, warehouses, chart of accounts, product-account mapping.

**Transaction Processing Layer** → Sales Order, Credit Approval, Shipping, Invoice, Cash Receipt, Inventory, Bank Reconciliation.

**Business Rule / Validation Layer** → reusable service functions for customer/product status, order totals, credit eligibility, stock, invoice eligibility, payment balance, invoice status and stock movement.

**Approval Workflow Layer** → Credit Officer approval for credit sales and Manager approval for discounts above the configurable prototype threshold (10%).

**Accounting Integration Layer** → simplified journal entries for shipment/COGS, invoice/AR/revenue/VAT, cash receipt/AR, and GRN/Inventory/AP.

**Inventory Integration Layer** → per-warehouse stock, stock movement history, GRN, transfers and adjustments.

**Audit / Reporting Layer** → audit logs, notifications, dashboard KPIs and reports calculated from SQLite transactions.

## 2. ERD / Database Relationships

```text
roles 1 ───< users
roles >───< permissions (through role_permissions)
payment_terms 1 ───< customers
customers 1 ───< sales_orders
sales_orders 1 ───< sales_order_details >───1 products
sales_orders 1 ───0..1 credit_approvals
sales_orders 1 ───< shippings 1 ───< shipping_details
shipping_details >───1 products
shippings 1 ───0..1 invoices
invoices 1 ───< invoice_details
invoices 1 ───< cash_receipts
customers 1 ───< invoices
products 1 ───1 product_accounts >─── chart_of_accounts
products 1 ───< inventory_stock >───1 warehouses
inventory movements reference operational transactions
bank_transactions 1 ───0..1 bank_reconciliations >─── cash_receipts
sales_orders 1 ───0..1 manager_approvals
```

The update specifically requires support for multiple product lines, multiple shipments against one Sales Order, remaining quantity tracking, and line-level partial shipping.

## 3. Role & Permission Matrix

| Role | Main permissions |
|---|---|
| Salesperson | Customers/products view, create/edit/submit own SOs |
| Credit Officer | View SOs and credit data; approve/reject credit; cannot create SO or ship |
| Warehouse / Inventory Staff | View SOs, create/confirm shipping, GRN, transfer, adjustment |
| Accounting / Billing Staff | View SO/shipping, create invoices, view AR, credit notes, bank reconciliation |
| Cashier | View invoices and record receipts; cannot issue invoices |
| Manager | Dashboard/reports/review plus configured manager approvals; not unrestricted editing |
| System Administrator | User management, role/permission assignment, selected master administration, audit viewing |

### Segregation of Duties

Salesperson → Credit Officer → Warehouse → Accounting/Billing → Cashier.

A salesperson cannot approve their own credit transaction. A cashier cannot issue invoices. Warehouse staff cannot post unrestricted accounting records.

## 4. Revenue Cycle Workflow

```text
CUSTOMER
   ↓
SALES ORDER (DRAFT)
   ↓ submit
SUBMITTED
   ├── CASH  → READY FOR SHIPPING
   └── CREDIT → PENDING CREDIT APPROVAL
                    ↓
               APPROVED / REJECTED
                    ↓
             READY FOR SHIPPING
                    ↓
             SHIPPING + STOCK UPDATE
                    ↓
                INVOICE
                    ↓
              ACCOUNTS RECEIVABLE
                    ↓
              CASH RECEIPT(S)
                    ↓
             BANK RECONCILIATION
                    ↓
          REPORTS / MANAGEMENT INFO
                    ↓
               AUDIT TRAIL
```

The updated specification requires rejected and blocked transactions to remain traceable, and it requires next-action logic after exceptions such as rejection, shortage and partial payment.

## 5. Internal Control Matrix

| Risk | Control implemented |
|---|---|
| Unauthorized access | Login + password hash + session |
| Unauthorized activity | RBAC + server-side permission decorators |
| Self-approval | Salesperson/approver user IDs are checked server-side |
| Credit over-limit | Available credit is recalculated from current AR |
| Shipping without approval | Credit sales require APPROVED credit decision |
| Negative/insufficient stock | Stock validated in the same transaction as shipment |
| Shipping > ordered | Remaining line quantity check |
| Duplicate invoice | `UNIQUE(shipping_id)` + backend validation |
| Payment over AR | Payment cannot exceed current outstanding balance |
| Invalid master data | ACTIVE customer/product validation |
| Unauthorized discounts | Configured >10% Manager approval workflow |
| Unexplained bank cash | Bank reconciliation status + exception/difference |
| Untraceable history | Immutable-style transaction records + audit logs; corrections use revision/reversal/adjustment concepts |

The updated prompt explicitly asks that failed critical actions be captured in the audit trail, not merely hidden as generic errors.

## 6. Business Rules

- INACTIVE customer → no new Sales Order.
- INACTIVE product → cannot be used on a Sales Order.
- Credit sale → credit approval required before shipping.
- Rejected/pending credit → shipping blocked.
- Shipping quantity must be >0, <= remaining order line quantity, and <= available stock at the selected warehouse.
- Sales Orders may be accepted even when current stock is insufficient; stock is rechecked at shipping.
- Multiple shipments are allowed against a Sales Order.
- Only shipped quantities are billable.
- Same shipment cannot be invoiced twice.
- Invoice payment amount must be >0 and <= outstanding.
- Invoice status is derived automatically as UNPAID/PARTIAL/PAID.
- Manager approval is required when any line discount exceeds the configurable 10% prototype threshold.
- Rejected SOs can be revised into a new Draft rather than silently changed.
- Important transaction history is not deleted.

The update specifically distinguishes normal processing from pending, approved, rejected, cancelled, partially completed and exception states.

## 7. Accounting + Inventory Integration

### Shipping
`SHIPPING → COGS debit + Inventory credit` using each product's Product→COA mapping and standard cost.

### Invoice
`INVOICE → Accounts Receivable debit + Sales Revenue credit + VAT Payable credit` based on shipped lines.

### Cash Receipt
`CASH/BANK debit + Accounts Receivable credit`.

### GRN
`Inventory debit + Accounts Payable credit`.

### Inventory value
Inventory quantity and inventory value are shown separately. Inventory value is calculated as `available_stock × standard_cost` for this prototype. The update explicitly requires the system to distinguish quantity from value and allow Accounting staff to view the related financial classification.

## 8. UI / UX

- Modern ERP-like layout.
- Fixed left sidebar.
- Top bar with current employee, employee ID, role and logout.
- Warm off-white page background.
- Brown corporate theme; no blue primary brand color.
- White/warm cards, rounded tables/forms and restrained shadows.
- Role-aware navigation and role-aware actions.
- Clear text status badges and user-facing business-rule messages.
- Responsive desktop/tablet layout.

## 9. Project Structure

```text
maju_jaya_ais/
├── app.py
├── auth.py
├── database.py
├── security.py
├── services.py
├── schema.sql
├── seed.py
├── init_db.py
├── run.py
├── requirements.txt
├── README.md
├── TEST_CASES.md
├── tests/
│   ├── test_core_logic.py
│   └── smoke_sqlite.py
├── templates/
│   ├── base.html
│   ├── login.html
│   ├── dashboard.html
│   ├── customers.html
│   ├── customer_create.html
│   ├── customer_detail.html
│   ├── products.html
│   ├── product_create.html
│   ├── product_detail.html
│   ├── sales_orders.html
│   ├── sales_order_create.html
│   ├── sales_order_detail.html
│   ├── credit_approvals.html
│   ├── credit_approval_detail.html
│   ├── manager_approvals.html
│   ├── shipping.html
│   ├── shipping_create.html
│   ├── shipping_detail.html
│   ├── invoices.html
│   ├── invoice_create.html
│   ├── invoice_detail.html
│   ├── cash_receipts.html
│   ├── cash_receipt_create.html
│   ├── cash_receipt_detail.html
│   ├── ar_ap.html
│   ├── credit_note_create.html
│   ├── inventory.html
│   ├── grn_create.html
│   ├── bank_reconciliation.html
│   ├── reports.html
│   ├── audit_logs.html
│   ├── users.html
│   ├── access_denied.html
│   └── error.html
└── static/
    ├── style.css
    └── script.js
```

## 10. Installation

### Windows

```powershell
cd maju_jaya_ais
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python seed.py
python run.py
```

Open `http://127.0.0.1:5000`.

### macOS / Linux

```bash
cd maju_jaya_ais
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python seed.py
python run.py
```

## 11. Demo Credentials

| Employee ID | Password | Role |
|---|---|---|
| EMP001 | `Sales@123` | Salesperson |
| EMP002 | `Credit@123` | Credit Officer |
| EMP003 | `Warehouse@123` | Warehouse / Inventory Staff |
| EMP004 | `Account@123` | Accounting / Billing Staff |
| EMP005 | `Cashier@123` | Cashier |
| EMP006 | `Manager@123` | Manager |
| EMP007 | `Admin@123` | System Administrator |

These are fictional demonstration identities only. Passwords are stored as PBKDF2-SHA256 hashes.

## 12. Database Initialization

`seed.py` recreates the demo state from scratch and inserts the required master/transaction data. `init_db.py` creates the schema without demo data.

The included `maju_jaya.db` is already seeded for convenience.

## 13. Demo Scenarios Included

1. Successful credit sale: approval → shipping → invoice → two receipts → PAID.
2. Pending credit approval.
3. Credit rejection with insufficient available credit.
4. Multiple-product order with line-level partial shipment.
5. Unpaid and partial invoices.
6. Bank reconciliation: one RECONCILED, one UNRECONCILED, one EXCEPTION.
7. Stock-shortage order: a ready-to-ship order that can be attempted at the warehouse and blocked if requested quantity is greater than location stock.
8. Discount >10% requiring Manager approval.

The updated prompt asks demo data to contain both successful and exception/control workflows, rather than only happy-path records.

## 14. Testing

### Smoke test

```bash
python tests/smoke_sqlite.py
```

### Core logic tests

```bash
python -m unittest tests/test_core_logic.py
```

### Application

Use the demo credentials above and test the end-to-end workflow:

1. Login as EMP001.
2. Open/create a Sales Order.
3. Submit a CREDIT order.
4. Login as EMP002 and approve/reject credit.
5. Login as EMP003 and create shipping.
6. Attempt an excessive shipment to verify stock/remaining-quantity blocking.
7. Login as EMP004 and create an invoice from an actual shipping transaction.
8. Login as EMP005 and record partial then final payment.
9. Login as EMP004 and reconcile the matching bank transaction.
10. Open Reports and Audit Trail to confirm the transaction chain.

## 15. Test Documentation

See `TEST_CASES.md` for 50 documented scenarios including the required scenarios from the master prompt and its update.

## 16. Important Assumptions

- Email verification is simulated in-app; no real email is sent.
- Tax rate is 11% for prototype purposes.
- Discount approval threshold is configurable in `services.py` and defaults to 10% as a demonstration control, not a universal accounting rule.
- Billing policy is shipment-based: only confirmed shipped quantities are billable.
- One shipping transaction can generate one invoice in this prototype. Multiple shipments against the same SO therefore produce separate billable shipment records.
- Standard cost is used for simplified COGS/inventory accounting.
- No real bank API is connected; bank transactions are demo input records.
- There is no full production-grade GL, procurement, supplier portal, or tax engine.

## 17. Prototype Limitations

This is an academic prototype, not a production ERP. It intentionally avoids advanced enterprise features such as distributed locking, external identity providers, production email/OTP infrastructure, real payment gateways, bank API ingestion, complex tax rules, multi-currency, formal approval hierarchies, and a complete general ledger.

## 18. Security Notes

- Passwords are hashed with PBKDF2-SHA256.
- Session cookie is HTTP-only and SameSite=Lax.
- Page routes and action routes use server-side permission checks.
- Audit records are not exposed for edit/delete in the UI.
- Historical invoices, cash receipts and confirmed shipments are not normal-edit/delete records.
- Critical failed/blocked actions are written to the audit trail where practical.

## 19. Academic Demonstration Focus

The strongest demonstration is the connected flow:

**CUSTOMER → SALES ORDER → CREDIT APPROVAL → SHIPPING → INVENTORY UPDATE → INVOICE → ACCOUNTS RECEIVABLE → CASH RECEIPT → BANK RECONCILIATION → REPORTS → AUDIT TRAIL**

This demonstrates transaction processing, information flow, validation, authorization, segregation of duties, accounting impact, inventory integration, auditability and management reporting in one relational system.
