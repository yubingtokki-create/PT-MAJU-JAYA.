import os
import sqlite3
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from functools import wraps

from flask import Flask, abort, flash, jsonify, redirect, render_template, request, session, url_for
from security import check_password, hash_password

from auth import get_current_user, has_permission, login_required, permission_required
from database import get_connection, init_db, transaction
from services import (
    MAX_DISCOUNT,
    TAX_RATE,
    add_audit,
    add_notification,
    calculate_available_credit,
    calculate_order,
    generate_number,
    generate_simple_number,
    get_customer_ar,
    inventory_adjust,
    issue_customer_verification_code,
    money,
    notify_role,
    post_accounting_entry,
    refresh_product_stock,
    require_transition,
    update_invoice_status,
    validate_customer_active,
    validate_product_active,
    verify_customer_email,
    now_iso,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-pt-maju-jaya-change-me")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

PERMISSION_PAGE_MAP = {
    "dashboard": "dashboard.view",
    "customers": "customer.view",
    "products": "product.view",
    "sales_orders": "sales_order.view",
    "credit_approvals": "credit_approval.view",
    "shipping": "shipping.view",
    "invoices": "invoice.view",
    "cash_receipts": "cash_receipt.view",
    "ar_ap": "ar.view",
    "inventory": "inventory.view",
    "bank_reconciliation": "bank_reconciliation.view",
    "reports": "report.view",
    "audit_logs": "audit.view",
    "users": "user.manage",
}


def _get_int(name, default=None):
    try:
        return int(request.form.get(name))
    except (TypeError, ValueError):
        return default


def _parse_decimal(value, field_label="Amount"):
    try:
        val = Decimal(str(value))
    except (InvalidOperation, TypeError):
        raise ValueError(f"{field_label} must be a valid number.")
    return val


def page_context():
    user = get_current_user()
    unread = 0
    notifications = []
    if user:
        conn = get_connection()
        try:
            unread = conn.execute("SELECT COUNT(*) c FROM notifications WHERE user_id=? AND is_read=0", (user["user_id"],)).fetchone()["c"]
            notifications = conn.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY notification_id DESC LIMIT 6", (user["user_id"],)).fetchall()
        finally:
            conn.close()
    return {"current_user": user, "unread_notifications": unread, "notifications": notifications, "today": date.today().isoformat()}


@app.context_processor
def inject_context():
    return {**page_context(), "has_permission": has_permission, "now": datetime.now()}


def route_permission(code):
    return permission_required(code)


def log_block(user, action, module, record_id, reason):
    try:
        add_audit(user, action, module, record_id, result="BLOCKED", reason=reason)
    except Exception:
        pass


def role_name(user):
    return user["role_name"] if user else None


def accounting_role(user):
    return role_name(user) in {"Accounting / Billing Staff", "Manager", "System Administrator"}


def warehouse_role(user):
    return role_name(user) in {"Warehouse / Inventory Staff", "Manager"}


def get_so_header(conn, so_id):
    return conn.execute(
        """SELECT so.*, c.customer_code,c.customer_name,c.email,c.phone,c.credit_limit,c.customer_status,
                  c.billing_address,c.delivery_address AS master_delivery,c.payment_term_id,
                  pt.term_code,pt.term_name,pt.days,
                  u.employee_id AS salesperson_employee,u.employee_name AS salesperson_name
           FROM sales_orders so JOIN customers c ON c.customer_id=so.customer_id
           JOIN payment_terms pt ON pt.payment_term_id=so.payment_term_id
           JOIN users u ON u.user_id=so.salesperson_id WHERE so.sales_order_id=?""", (so_id,)
    ).fetchone()


def get_so_lines(conn, so_id):
    return conn.execute(
        """SELECT sod.*, p.product_code,p.product_name,p.category,p.brand,p.unit,p.available_stock,p.product_status,
                  COALESCE((SELECT SUM(sd.quantity_shipped) FROM shipping_details sd WHERE sd.sales_order_detail_id=sod.sales_order_detail_id
                            JOIN shippings sh ON sh.shipping_id=sd.shipping_id WHERE sh.shipping_status='SHIPPED'),0) shipped_qty
           FROM sales_order_details sod JOIN products p ON p.product_id=sod.product_id
           WHERE sod.sales_order_id=? ORDER BY sod.sales_order_detail_id""", (so_id,)
    ).fetchall()


def get_order_flow(conn, so_id):
    so = conn.execute("SELECT * FROM sales_orders WHERE sales_order_id=?", (so_id,)).fetchone()
    credit = conn.execute("SELECT * FROM credit_approvals WHERE sales_order_id=?", (so_id,)).fetchone()
    shippings = conn.execute("SELECT * FROM shippings WHERE sales_order_id=? ORDER BY shipping_id", (so_id,)).fetchall()
    invoices = conn.execute("SELECT * FROM invoices WHERE sales_order_id=? ORDER BY invoice_id", (so_id,)).fetchall()
    receipts = conn.execute(
        """SELECT cr.* FROM cash_receipts cr JOIN invoices i ON i.invoice_id=cr.invoice_id
           WHERE i.sales_order_id=? ORDER BY cr.receipt_id""", (so_id,)
    ).fetchall()
    return so, credit, shippings, invoices, receipts


@app.route("/", methods=["GET"])
def index():
    if get_current_user():
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        employee_id = (request.form.get("employee_id") or "").strip()
        password = request.form.get("password") or ""
        conn = get_connection()
        user = conn.execute(
            """SELECT u.*, r.role_name FROM users u JOIN roles r ON r.role_id=u.role_id
               WHERE u.employee_id=?""", (employee_id,)
        ).fetchone()
        if not user or not user["is_active"] or not check_password(user["password_hash"], password):
            if user:
                conn.execute("UPDATE users SET failed_login_count=failed_login_count+1 WHERE user_id=?", (user["user_id"],))
                conn.commit()
            add_audit(user if user else None, "FAILED LOGIN", "AUTHENTICATION", user["user_id"] if user else employee_id, result="FAILED", reason="Invalid credentials or inactive account", conn=conn)
            conn.close()
            flash("Invalid employee ID or password.", "error")
            return render_template("login.html")
        conn.execute("UPDATE users SET failed_login_count=0,last_login_at=? WHERE user_id=?", (now_iso(), user["user_id"]))
        add_audit(user, "LOGIN", "AUTHENTICATION", user["user_id"], conn=conn)
        conn.commit()
        conn.close()
        session.clear()
        session["user_id"] = user["user_id"]
        session.permanent = True
        flash(f"Welcome, {user['employee_name']}.", "success")
        return redirect(url_for("dashboard"))
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    user = get_current_user()
    add_audit(user, "LOGOUT", "AUTHENTICATION", user["user_id"])
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


@app.route("/access-denied")
def access_denied():
    return render_template("access_denied.html")


@app.route("/dashboard")
@route_permission("dashboard.view")
def dashboard():
    user = get_current_user()
    conn = get_connection()
    try:
        metrics = {}
        metrics["customers"] = conn.execute("SELECT COUNT(*) c FROM customers").fetchone()["c"]
        metrics["active_customers"] = conn.execute("SELECT COUNT(*) c FROM customers WHERE customer_status='ACTIVE'").fetchone()["c"]
        metrics["products"] = conn.execute("SELECT COUNT(*) c FROM products WHERE product_status='ACTIVE'").fetchone()["c"]
        metrics["orders"] = conn.execute("SELECT COUNT(*) c FROM sales_orders").fetchone()["c"]
        metrics["invoices"] = conn.execute("SELECT COUNT(*) c FROM invoices WHERE invoice_status<>'CANCELLED'").fetchone()["c"]
        metrics["revenue"] = money(conn.execute("SELECT COALESCE(SUM(invoice_amount),0) x FROM invoices WHERE invoice_status<>'CANCELLED'").fetchone()["x"])
        metrics["collected"] = money(conn.execute("SELECT COALESCE(SUM(amount),0) x FROM cash_receipts WHERE status='POSTED'").fetchone()["x"])
        metrics["outstanding_ar"] = money(conn.execute("SELECT COALESCE(SUM(outstanding_amount),0) x FROM invoices WHERE invoice_status<>'CANCELLED'").fetchone()["x"])
        metrics["pending_credit"] = conn.execute("SELECT COUNT(*) c FROM sales_orders WHERE order_status='PENDING CREDIT APPROVAL'").fetchone()["c"]
        metrics["pending_shipments"] = conn.execute("SELECT COUNT(*) c FROM sales_orders WHERE order_status IN ('READY FOR SHIPPING','PARTIALLY SHIPPED')").fetchone()["c"]
        metrics["unpaid"] = conn.execute("SELECT COUNT(*) c FROM invoices WHERE invoice_status='UNPAID'").fetchone()["c"]
        metrics["partial"] = conn.execute("SELECT COUNT(*) c FROM invoices WHERE invoice_status='PARTIAL'").fetchone()["c"]
        metrics["paid"] = conn.execute("SELECT COUNT(*) c FROM invoices WHERE invoice_status='PAID'").fetchone()["c"]
        metrics["unreconciled_bank"] = conn.execute("SELECT COUNT(*) c FROM bank_reconciliations WHERE reconciliation_status='UNRECONCILED'").fetchone()["c"]
        metrics["exceptions"] = conn.execute("SELECT COUNT(*) c FROM bank_reconciliations WHERE reconciliation_status='EXCEPTION'").fetchone()["c"]
        metrics["rejected"] = conn.execute("SELECT COUNT(*) c FROM sales_orders WHERE order_status='REJECTED'").fetchone()["c"]
        metrics["credit_sales"] = money(conn.execute("SELECT COALESCE(SUM(grand_total),0) x FROM sales_orders WHERE sales_type='CREDIT' AND order_status NOT IN ('DRAFT','REJECTED')").fetchone()["x"])
        metrics["cash_sales"] = money(conn.execute("SELECT COALESCE(SUM(grand_total),0) x FROM sales_orders WHERE sales_type='CASH' AND order_status NOT IN ('DRAFT','REJECTED')").fetchone()["x"])
        metrics["low_stock"] = conn.execute("SELECT COUNT(*) c FROM products WHERE product_status='ACTIVE' AND available_stock < 8").fetchone()["c"]
        metrics["inventory_value"] = money(conn.execute("SELECT COALESCE(SUM(available_stock*standard_cost),0) x FROM products WHERE product_status='ACTIVE'").fetchone()["x"])
        metrics["today_collected"] = money(conn.execute("SELECT COALESCE(SUM(amount),0) x FROM cash_receipts WHERE status='POSTED' AND receipt_date=date('now')").fetchone()["x"])
        metrics["my_orders"] = conn.execute("SELECT COUNT(*) c FROM sales_orders WHERE salesperson_id=?",(user["user_id"],)).fetchone()["c"]
        metrics["my_drafts"] = conn.execute("SELECT COUNT(*) c FROM sales_orders WHERE salesperson_id=? AND order_status='DRAFT'",(user["user_id"],)).fetchone()["c"]
        metrics["my_pending"] = conn.execute("SELECT COUNT(*) c FROM sales_orders WHERE salesperson_id=? AND order_status='PENDING CREDIT APPROVAL'",(user["user_id"],)).fetchone()["c"]
        metrics["my_approved"] = conn.execute("SELECT COUNT(*) c FROM sales_orders WHERE salesperson_id=? AND order_status IN ('APPROVED','READY FOR SHIPPING')",(user["user_id"],)).fetchone()["c"]
        metrics["my_rejected"] = conn.execute("SELECT COUNT(*) c FROM sales_orders WHERE salesperson_id=? AND order_status='REJECTED'",(user["user_id"],)).fetchone()["c"]
        metrics["approved_today"] = conn.execute("SELECT COUNT(*) c FROM credit_approvals WHERE decision='APPROVED' AND date(approval_date)=date('now')").fetchone()["c"]
        metrics["rejected_today"] = conn.execute("SELECT COUNT(*) c FROM credit_approvals WHERE decision='REJECTED' AND date(approval_date)=date('now')").fetchone()["c"]
        role = role_name(user)
        recent = []
        title = "Dashboard"
        subtitle = "Integrated Revenue Cycle and AIS monitoring"
        if role == "Salesperson":
            recent = conn.execute("SELECT so.*,c.customer_name FROM sales_orders so JOIN customers c ON c.customer_id=so.customer_id WHERE so.salesperson_id=? ORDER BY so.sales_order_id DESC LIMIT 8", (user["user_id"],)).fetchall()
        elif role == "Credit Officer":
            recent = conn.execute("SELECT ca.*,so.so_number,c.customer_name FROM credit_approvals ca JOIN sales_orders so ON so.sales_order_id=ca.sales_order_id JOIN customers c ON c.customer_id=ca.customer_id WHERE ca.decision IS NULL ORDER BY ca.credit_approval_id DESC").fetchall()
        elif role in {"Warehouse / Inventory Staff"}:
            recent = conn.execute("SELECT so.so_number,c.customer_name,so.order_status FROM sales_orders so JOIN customers c ON c.customer_id=so.customer_id WHERE so.order_status IN ('READY FOR SHIPPING','PARTIALLY SHIPPED') ORDER BY so.sales_order_id DESC").fetchall()
        elif role in {"Accounting / Billing Staff", "Cashier"}:
            recent = conn.execute("SELECT i.*,c.customer_name FROM invoices i JOIN customers c ON c.customer_id=i.customer_id WHERE i.invoice_status<>'PAID' ORDER BY i.invoice_id DESC LIMIT 10").fetchall()
        else:
            recent = conn.execute("SELECT so.so_number,c.customer_name,so.order_status,so.grand_total FROM sales_orders so JOIN customers c ON c.customer_id=so.customer_id ORDER BY so.sales_order_id DESC LIMIT 10").fetchall()
        return render_template("dashboard.html", metrics=metrics, recent=recent, title=title, subtitle=subtitle, role=role)
    finally:
        conn.close()


@app.route("/customers")
@route_permission("customer.view")
def customers():
    conn = get_connection()
    try:
        rows = conn.execute("""SELECT c.*,pt.term_name FROM customers c JOIN payment_terms pt ON pt.payment_term_id=c.payment_term_id ORDER BY c.customer_id DESC""").fetchall()
        return render_template("customers.html", customers=rows)
    finally:
        conn.close()


@app.route("/customers/new", methods=["GET", "POST"])
@route_permission("customer.create")
def customer_create():
    user = get_current_user()
    conn = get_connection()
    if request.method == "POST":
        try:
            required = ["customer_name","customer_type","contact_person","phone","email","billing_address","delivery_address","city","province","postal_code","credit_limit","payment_term_id"]
            if any(not (request.form.get(k) or "").strip() for k in required):
                raise ValueError("Required field is missing.")
            credit_limit = _parse_decimal(request.form.get("credit_limit"), "Credit limit")
            if credit_limit < 0:
                raise ValueError("Credit limit cannot be negative.")
            code = generate_simple_number(conn, "CUST", "customers", "customer_code")
            row = conn.execute(
                """INSERT INTO customers(customer_code,customer_name,customer_type,npwp,contact_person,phone,email,billing_address,delivery_address,city,province,postal_code,credit_limit,payment_term_id,customer_status,created_by,updated_date)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'ACTIVE',?,?)""",
                (code,request.form["customer_name"].strip(),request.form["customer_type"],request.form.get("npwp"),request.form["contact_person"].strip(),request.form["phone"].strip(),request.form["email"].strip(),request.form["billing_address"].strip(),request.form["delivery_address"].strip(),request.form["city"].strip(),request.form["province"].strip(),request.form["postal_code"].strip(),credit_limit,_get_int("payment_term_id"),user["user_id"],now_iso()),
            )
            customer_id = row.lastrowid
            add_audit(user,"CUSTOMER CREATED","CUSTOMER",customer_id,new_value={"customer_code":code,"customer_name":request.form["customer_name"]},conn=conn)
            conn.commit()
            conn.close()
            flash(f"Customer {code} created.", "success")
            return redirect(url_for("customer_detail", id=customer_id))
        except (ValueError, sqlite3.IntegrityError) as exc:
            conn.rollback()
            log_block(user,"CUSTOMER CREATE FAILED","CUSTOMER",request.form.get("customer_name"),str(exc))
            flash(str(exc) if isinstance(exc, ValueError) else "Customer code or data already exists.", "error")
    terms = conn.execute("SELECT * FROM payment_terms ORDER BY days").fetchall()
    conn.close()
    return render_template("customer_create.html", payment_terms=terms)


@app.route("/customers/<int:id>")
@route_permission("customer.view")
def customer_detail(id):
    conn = get_connection()
    try:
        customer = conn.execute("""SELECT c.*,pt.term_name,pt.days FROM customers c JOIN payment_terms pt ON pt.payment_term_id=c.payment_term_id WHERE c.customer_id=?""", (id,)).fetchone()
        if not customer:
            abort(404)
        ar = get_customer_ar(conn, id)
        orders = conn.execute("SELECT so_number,order_date,grand_total,order_status,sales_type FROM sales_orders WHERE customer_id=? ORDER BY sales_order_id DESC LIMIT 10", (id,)).fetchall()
        return render_template("customer_detail.html", customer=customer, ar=ar, orders=orders)
    finally:
        conn.close()


@app.route("/customers/<int:id>/verification/send", methods=["POST"])
@route_permission("customer.edit")
def customer_verification_send(id):
    user = get_current_user()
    with transaction() as conn:
        customer = conn.execute("SELECT * FROM customers WHERE customer_id=?", (id,)).fetchone()
        if not customer:
            abort(404)
        code, expiry = issue_customer_verification_code(conn, id)
        add_audit(user,"VERIFICATION CODE SENT","CUSTOMER",id,new_value={"simulated":True,"expires_at":expiry.isoformat()},conn=conn)
    flash(f"Demo email sent. Verification code (SIMULATED): {code}", "info")
    return redirect(url_for("customer_detail", id=id))


@app.route("/customers/<int:id>/verification/verify", methods=["POST"])
@route_permission("customer.edit")
def customer_verification_verify(id):
    user = get_current_user()
    try:
        with transaction() as conn:
            verify_customer_email(conn, id, (request.form.get("code") or "").strip())
            add_audit(user,"CUSTOMER EMAIL VERIFIED","CUSTOMER",id,conn=conn)
        flash("Customer email verified successfully.", "success")
    except ValueError as exc:
        add_audit(user,"CUSTOMER EMAIL VERIFICATION BLOCKED","CUSTOMER",id,result="BLOCKED",reason=str(exc))
        flash(str(exc), "error")
    return redirect(url_for("customer_detail", id=id))


@app.route("/customers/<int:id>/toggle", methods=["POST"])
@route_permission("customer.edit")
def customer_toggle(id):
    user = get_current_user()
    with transaction() as conn:
        row = conn.execute("SELECT customer_status FROM customers WHERE customer_id=?", (id,)).fetchone()
        if not row:
            abort(404)
        new_status = "INACTIVE" if row["customer_status"] == "ACTIVE" else "ACTIVE"
        conn.execute("UPDATE customers SET customer_status=?,updated_date=? WHERE customer_id=?", (new_status,now_iso(),id))
        add_audit(user,"CUSTOMER STATUS CHANGE","CUSTOMER",id,old_value=row["customer_status"],new_value=new_status,conn=conn)
    flash(f"Customer status changed to {new_status}.", "success")
    return redirect(url_for("customer_detail", id=id))


@app.route("/products")
@route_permission("product.view")
def products():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT p.*,coa1.account_code inventory_code,coa1.account_name inventory_account,coa2.account_code sales_code,coa3.account_code cogs_code FROM products p LEFT JOIN product_accounts pa ON pa.product_id=p.product_id LEFT JOIN chart_of_accounts coa1 ON coa1.account_id=pa.inventory_account_id LEFT JOIN chart_of_accounts coa2 ON coa2.account_id=pa.sales_account_id LEFT JOIN chart_of_accounts coa3 ON coa3.account_id=pa.cogs_account_id ORDER BY p.product_id DESC").fetchall()
        return render_template("products.html", products=rows)
    finally:
        conn.close()


@app.route("/products/new", methods=["GET", "POST"])
@route_permission("product.create")
def product_create():
    user = get_current_user()
    conn = get_connection()
    if request.method == "POST":
        try:
            for k in ["product_name","category","brand","unit","selling_price","standard_cost"]:
                if not (request.form.get(k) or "").strip():
                    raise ValueError("Required field is missing.")
            price = _parse_decimal(request.form["selling_price"],"Selling price")
            cost = _parse_decimal(request.form["standard_cost"],"Standard cost")
            if price < 0 or cost < 0:
                raise ValueError("Price/cost cannot be negative.")
            code = generate_simple_number(conn,"PROD","products","product_code")
            row = conn.execute("INSERT INTO products(product_code,product_name,category,brand,description,unit,selling_price,available_stock,standard_cost,product_status,updated_date) VALUES(?,?,?,?,?,?,?,?,?,'ACTIVE',?)",(code,request.form["product_name"].strip(),request.form["category"],request.form["brand"],request.form.get("description"),request.form["unit"],price,0,cost,now_iso()))
            product_id=row.lastrowid
            inventory_id=_get_int("inventory_account_id"); sales_id=_get_int("sales_account_id"); cogs_id=_get_int("cogs_account_id")
            if not all([inventory_id,sales_id,cogs_id]):
                raise ValueError("All three COA mappings are required.")
            conn.execute("INSERT INTO product_accounts(product_id,inventory_account_id,sales_account_id,cogs_account_id) VALUES(?,?,?,?)",(product_id,inventory_id,sales_id,cogs_id))
            add_audit(user,"PRODUCT CREATED","PRODUCT",product_id,conn=conn)
            conn.commit(); conn.close()
            flash(f"Product {code} created.","success")
            return redirect(url_for("product_detail",id=product_id))
        except (ValueError, sqlite3.IntegrityError) as exc:
            conn.rollback(); log_block(user,"PRODUCT CREATE FAILED","PRODUCT",request.form.get("product_name"),str(exc))
            flash(str(exc) if isinstance(exc,ValueError) else "Product data already exists or is invalid.","error")
    accounts = conn.execute("SELECT * FROM chart_of_accounts ORDER BY account_code").fetchall()
    conn.close()
    return render_template("product_create.html",accounts=accounts)


@app.route("/products/<int:id>")
@route_permission("product.view")
def product_detail(id):
    conn=get_connection()
    try:
        p=conn.execute("""SELECT p.*,coa1.account_code inventory_code,coa1.account_name inventory_account,coa2.account_code sales_code,coa2.account_name sales_account,coa3.account_code cogs_code,coa3.account_name cogs_account FROM products p LEFT JOIN product_accounts pa ON pa.product_id=p.product_id LEFT JOIN chart_of_accounts coa1 ON coa1.account_id=pa.inventory_account_id LEFT JOIN chart_of_accounts coa2 ON coa2.account_id=pa.sales_account_id LEFT JOIN chart_of_accounts coa3 ON coa3.account_id=pa.cogs_account_id WHERE p.product_id=?""",(id,)).fetchone()
        if not p: abort(404)
        stock=conn.execute("""SELECT s.quantity,w.warehouse_code,w.warehouse_name FROM inventory_stock s JOIN warehouses w ON w.warehouse_id=s.warehouse_id WHERE s.product_id=? ORDER BY w.warehouse_id""",(id,)).fetchall()
        movements=conn.execute("""SELECT im.*,w.warehouse_name FROM inventory_movements im JOIN warehouses w ON w.warehouse_id=im.warehouse_id WHERE im.product_id=? ORDER BY im.movement_id DESC LIMIT 20""",(id,)).fetchall()
        return render_template("product_detail.html",product=p,stock=stock,movements=movements)
    finally: conn.close()


@app.route("/products/<int:id>/toggle", methods=["POST"])
@route_permission("product.edit")
def product_toggle(id):
    user=get_current_user()
    with transaction() as conn:
        row=conn.execute("SELECT product_status FROM products WHERE product_id=?",(id,)).fetchone()
        if not row: abort(404)
        new_status="INACTIVE" if row["product_status"]=="ACTIVE" else "ACTIVE"
        conn.execute("UPDATE products SET product_status=?,updated_date=? WHERE product_id=?",(new_status,now_iso(),id))
        add_audit(user,"PRODUCT STATUS CHANGE","PRODUCT",id,old_value=row["product_status"],new_value=new_status,conn=conn)
    flash(f"Product status changed to {new_status}.","success")
    return redirect(url_for("product_detail",id=id))


@app.route("/sales-orders")
@route_permission("sales_order.view")
def sales_orders():
    user=get_current_user(); conn=get_connection()
    try:
        sql="""SELECT so.*,c.customer_name,u.employee_name salesperson FROM sales_orders so JOIN customers c ON c.customer_id=so.customer_id JOIN users u ON u.user_id=so.salesperson_id"""
        params=[]
        if role_name(user)=="Salesperson":
            sql += " WHERE so.salesperson_id=?"; params.append(user["user_id"])
        sql += " ORDER BY so.sales_order_id DESC"
        rows=conn.execute(sql,params).fetchall()
        return render_template("sales_orders.html",sales_orders=rows)
    finally: conn.close()


@app.route("/sales-orders/new", methods=["GET","POST"])
@route_permission("sales_order.create")
def sales_order_create():
    user=get_current_user(); conn=get_connection()
    if request.method=="POST":
        try:
            customer_id=_get_int("customer_id")
            validate_customer_active(conn,customer_id)
            sales_type=request.form.get("sales_type")
            payment_term_id=_get_int("payment_term_id")
            delivery_date=request.form.get("delivery_date")
            if not delivery_date: raise ValueError("Delivery Date is required.")
            delivery_dt=datetime.strptime(delivery_date,"%Y-%m-%d").date()
            if delivery_dt < date.today(): raise ValueError("Delivery Date must be valid and cannot be in the past.")
            shipping_cost=_parse_decimal(request.form.get("shipping_cost",0),"Shipping cost")
            if shipping_cost < 0: raise ValueError("Shipping cost cannot be negative.")
            product_ids=request.form.getlist("product_id[]")
            quantities=request.form.getlist("quantity[]")
            discounts=request.form.getlist("discount_percentage[]")
            if not product_ids or len(product_ids)!=len(quantities): raise ValueError("At least one product line is required.")
            lines=[]
            seen=set()
            for pid,q,disc in zip(product_ids,quantities,discounts or ["0"]*len(product_ids)):
                pid=int(pid)
                if pid in seen: raise ValueError("The same product cannot be added twice to one Sales Order.")
                seen.add(pid)
                product=validate_product_active(conn,pid)
                qty=_parse_decimal(q,"Quantity")
                if qty<=0: raise ValueError("Quantity must be greater than 0.")
                lines.append({"product_id":pid,"quantity":qty,"unit_price":money(product["selling_price"]),"discount_percentage":_parse_decimal(disc or 0,"Discount")})
            normalized,subtotal,discount,tax,grand_total,max_discount=calculate_order(lines,shipping_cost)
            discount_required=max_discount>MAX_DISCOUNT
            code=generate_number(conn,"SO","sales_orders","so_number")
            customer=conn.execute("SELECT delivery_address FROM customers WHERE customer_id=?",(customer_id,)).fetchone()
            initial_status="DRAFT"
            row=conn.execute("""INSERT INTO sales_orders(so_number,order_date,customer_id,salesperson_id,sales_type,payment_term_id,delivery_date,delivery_address,shipping_cost,tax,subtotal,discount,grand_total,order_status,customer_notes,internal_notes,discount_approval_required,discount_approval_status,created_by,updated_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(code,date.today().isoformat(),customer_id,user["user_id"],sales_type,payment_term_id,delivery_date,customer["delivery_address"],shipping_cost,tax,subtotal,discount,grand_total,initial_status,request.form.get("customer_notes"),request.form.get("internal_notes"),1 if discount_required else 0,"PENDING" if discount_required else "NOT_REQUIRED",user["user_id"],now_iso()))
            so_id=row.lastrowid
            for line in normalized:
                conn.execute("INSERT INTO sales_order_details(sales_order_id,product_id,quantity,unit_price,discount_percentage,discount_amount,line_subtotal) VALUES(?,?,?,?,?,?,?)",(so_id,line["product_id"],line["quantity"],line["unit_price"],line["discount_percentage"],line["discount_amount"],line["line_subtotal"]))
            if discount_required:
                conn.execute("INSERT INTO manager_approvals(entity_type,entity_id,requested_discount,maximum_allowed_discount,approval_status) VALUES('SALES_ORDER',?,?,?,'PENDING')",(so_id,max_discount,MAX_DISCOUNT))
                notify_role("Manager",f"Sales Order {code} requires discount approval.","SALES_ORDER",so_id,conn=conn)
            add_audit(user,"SALES ORDER CREATED","SALES_ORDER",so_id,new_value={"so_number":code,"grand_total":str(grand_total)},conn=conn)
            conn.commit(); conn.close()
            flash(f"Sales Order {code} created as DRAFT.","success")
            return redirect(url_for("sales_order_detail",id=so_id))
        except (ValueError, sqlite3.IntegrityError) as exc:
            conn.rollback(); log_block(user,"SALES ORDER CREATE BLOCKED","SALES_ORDER",None,str(exc)); flash(str(exc),"error")
    customers_list=conn.execute("SELECT customer_id,customer_code,customer_name,email,phone,credit_limit,delivery_address,customer_status,payment_term_id FROM customers WHERE customer_status='ACTIVE' ORDER BY customer_name").fetchall()
    products_list=conn.execute("SELECT product_id,product_code,product_name,category,brand,unit,selling_price,available_stock FROM products WHERE product_status='ACTIVE' ORDER BY product_name").fetchall()
    terms=conn.execute("SELECT * FROM payment_terms ORDER BY days").fetchall()
    conn.close()
    return render_template("sales_order_create.html",customers=customers_list,products=products_list,payment_terms=terms,tax_rate=TAX_RATE)


@app.route("/sales-orders/<int:id>")
@route_permission("sales_order.view")
def sales_order_detail(id):
    user=get_current_user(); conn=get_connection()
    try:
        so=get_so_header(conn,id)
        if not so: abort(404)
        if role_name(user)=="Salesperson" and so["salesperson_id"]!=user["user_id"]:
            flash("You can only view Sales Orders you are authorized to view.","error"); return redirect(url_for("access_denied"))
        lines=get_so_lines(conn,id)
        flow=get_order_flow(conn,id)
        manager_approval=conn.execute("SELECT * FROM manager_approvals WHERE entity_type='SALES_ORDER' AND entity_id=?",(id,)).fetchone()
        return render_template("sales_order_detail.html",so=so,lines=lines,credit=flow[1],shippings=flow[2],invoices=flow[3],receipts=flow[4],manager_approval=manager_approval)
    finally: conn.close()


@app.route("/sales-orders/<int:id>/submit", methods=["POST"])
@route_permission("sales_order.submit")
def sales_order_submit(id):
    user=get_current_user()
    with transaction() as conn:
        so=conn.execute("SELECT * FROM sales_orders WHERE sales_order_id=?",(id,)).fetchone()
        if not so: abort(404)
        if so["salesperson_id"]!=user["user_id"] and role_name(user)!="Manager":
            log_block(user,"SALES ORDER SUBMIT BLOCKED","SALES_ORDER",id,"Salesperson authorization mismatch")
            flash("You are not authorized to submit this Sales Order.","error"); return redirect(url_for("access_denied"))
        if so["order_status"]!="DRAFT":
            raise ValueError("Only DRAFT Sales Orders can be submitted.")
        if so["discount_approval_required"] and so["discount_approval_status"]!="APPROVED":
            raise ValueError("Manager discount approval is required before submission.")
        require_transition(so["order_status"],"SUBMITTED")
        next_status="PENDING CREDIT APPROVAL" if so["sales_type"]=="CREDIT" else "READY FOR SHIPPING"
        conn.execute("UPDATE sales_orders SET order_status=?,updated_date=? WHERE sales_order_id=?",("SUBMITTED",now_iso(),id))
        add_audit(user,"SALES ORDER SUBMITTED","SALES_ORDER",id,old_value="DRAFT",new_value="SUBMITTED",conn=conn)
        if so["sales_type"]=="CREDIT":
            limit,outstanding,available,eligible=calculate_available_credit(conn,so["customer_id"],so["grand_total"])
            ca_num=generate_number(conn,"CA","credit_approvals","approval_number")
            conn.execute("""INSERT INTO credit_approvals(approval_number,sales_order_id,customer_id,credit_limit,outstanding_balance,order_amount,available_credit,eligibility_result) VALUES(?,?,?,?,?,?,?,?)""",(ca_num,id,so["customer_id"],limit,outstanding,so["grand_total"],available,"ELIGIBLE" if eligible else "NOT ELIGIBLE"))
            conn.execute("UPDATE sales_orders SET order_status='PENDING CREDIT APPROVAL',updated_date=? WHERE sales_order_id=?",(now_iso(),id))
            notify_role("Credit Officer",f"Sales Order {so['so_number']} requires credit approval.","CREDIT_APPROVAL",id,conn=conn)
            next_status="PENDING CREDIT APPROVAL"
        else:
            conn.execute("UPDATE sales_orders SET order_status='READY FOR SHIPPING',updated_date=? WHERE sales_order_id=?",(now_iso(),id))
            notify_role("Warehouse / Inventory Staff",f"Sales Order {so['so_number']} is ready for shipping.","SALES_ORDER",id,conn=conn)
            next_status="READY FOR SHIPPING"
        add_audit(user,"STATUS CHANGE","SALES_ORDER",id,old_value="SUBMITTED",new_value=next_status,conn=conn)
    flash(f"Sales Order moved to {next_status}.","success")
    return redirect(url_for("sales_order_detail",id=id))


@app.route("/sales-orders/<int:id>/revise", methods=["POST"])
@route_permission("sales_order.create")
def sales_order_revise(id):
    user=get_current_user()
    with transaction() as conn:
        old=conn.execute("SELECT * FROM sales_orders WHERE sales_order_id=?",(id,)).fetchone()
        if not old: abort(404)
        if old["order_status"]!="REJECTED": raise ValueError("Only rejected Sales Orders can be revised.")
        if role_name(user)=="Salesperson" and old["salesperson_id"]!=user["user_id"]: raise ValueError("You are not authorized to revise this Sales Order.")
        code=generate_number(conn,"SO","sales_orders","so_number")
        row=conn.execute("""INSERT INTO sales_orders(so_number,order_date,customer_id,salesperson_id,sales_type,payment_term_id,delivery_date,delivery_address,shipping_cost,tax,subtotal,discount,grand_total,order_status,customer_notes,internal_notes,discount_approval_required,discount_approval_status,revision_of_id,created_by,updated_date)
                           SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? FROM sales_orders WHERE sales_order_id=?""",(code,date.today().isoformat(),old["customer_id"],user["user_id"],old["sales_type"],old["payment_term_id"],old["delivery_date"],old["delivery_address"],old["shipping_cost"],0,0,0,0,"DRAFT",old["customer_notes"],f"Revision of {old['so_number']}",0,"NOT_REQUIRED",id,user["user_id"],now_iso(),id))
        new_id=row.lastrowid
        old_lines=conn.execute("SELECT * FROM sales_order_details WHERE sales_order_id=?",(id,)).fetchall()
        for l in old_lines:
            conn.execute("INSERT INTO sales_order_details(sales_order_id,product_id,quantity,unit_price,discount_percentage,discount_amount,line_subtotal) VALUES(?,?,?,?,?,?,?)",(new_id,l["product_id"],l["quantity"],l["unit_price"],l["discount_percentage"],l["discount_amount"],l["line_subtotal"]))
        normalized=[{"quantity":l["quantity"],"unit_price":l["unit_price"],"discount_percentage":l["discount_percentage"]} for l in old_lines]
        _,sub,disc,tax,gt,md=calculate_order(normalized,old["shipping_cost"])
        conn.execute("UPDATE sales_orders SET subtotal=?,discount=?,tax=?,grand_total=?,discount_approval_required=?,discount_approval_status=? WHERE sales_order_id=?",(sub,disc,tax,gt,1 if md>MAX_DISCOUNT else 0,"PENDING" if md>MAX_DISCOUNT else "NOT_REQUIRED",new_id))
        if md>MAX_DISCOUNT:
            conn.execute("INSERT INTO manager_approvals(entity_type,entity_id,requested_discount,maximum_allowed_discount,approval_status) VALUES('SALES_ORDER',?,?,?,'PENDING')",(new_id,md,MAX_DISCOUNT))
        add_audit(user,"SALES ORDER REVISION CREATED","SALES_ORDER",new_id,new_value={"revision_of":old["so_number"]},conn=conn)
        notify_role("Salesperson",f"Revision {code} created from rejected {old['so_number']}.","SALES_ORDER",new_id,exclude_user_id=user["user_id"],conn=conn)
    flash(f"Revision {code} created as DRAFT.","success")
    return redirect(url_for("sales_order_detail",id=new_id))


@app.route("/credit-approvals")
@route_permission("credit_approval.view")
def credit_approvals():
    conn=get_connection()
    try:
        rows=conn.execute("""SELECT ca.*,ca.approval_number,so.so_number,so.order_status,c.customer_name,u.employee_name salesperson
                           FROM credit_approvals ca JOIN sales_orders so ON so.sales_order_id=ca.sales_order_id JOIN customers c ON c.customer_id=ca.customer_id JOIN users u ON u.user_id=so.salesperson_id ORDER BY ca.credit_approval_id DESC""").fetchall()
        return render_template("credit_approvals.html",approvals=rows)
    finally: conn.close()


@app.route("/credit-approvals/<int:id>")
@route_permission("credit_approval.view")
def credit_approval_detail(id):
    conn=get_connection()
    try:
        ca=conn.execute("""SELECT ca.*,so.so_number,so.grand_total,so.sales_type,so.salesperson_id,so.order_status,c.customer_code,c.customer_name,c.credit_limit,u.employee_id salesperson_employee,u.employee_name salesperson_name FROM credit_approvals ca JOIN sales_orders so ON so.sales_order_id=ca.sales_order_id JOIN customers c ON c.customer_id=ca.customer_id JOIN users u ON u.user_id=so.salesperson_id WHERE ca.credit_approval_id=?""",(id,)).fetchone()
        if not ca: abort(404)
        return render_template("credit_approval_detail.html",approval=ca)
    finally: conn.close()


@app.route("/credit-approvals/<int:id>/decision", methods=["POST"])
@route_permission("credit_approval.decide")
def credit_approval_decision(id):
    user=get_current_user(); decision=request.form.get("decision")
    try:
        with transaction() as conn:
            ca=conn.execute("SELECT * FROM credit_approvals WHERE credit_approval_id=?",(id,)).fetchone()
            if not ca: abort(404)
            so=conn.execute("SELECT * FROM sales_orders WHERE sales_order_id=?",(ca["sales_order_id"],)).fetchone()
            if so["salesperson_id"]==user["user_id"]:
                raise ValueError("You cannot approve your own credit transaction.")
            if so["sales_type"]!="CREDIT" or so["order_status"]!="PENDING CREDIT APPROVAL":
                raise ValueError("Credit approval is not available for this transaction state.")
            if decision not in {"APPROVED","REJECTED"}: raise ValueError("Invalid credit decision.")
            # Recalculate using current source data, never trust stale client values.
            limit,outstanding,available,eligible=calculate_available_credit(conn,so["customer_id"],so["grand_total"])
            final_decision="APPROVED" if decision=="APPROVED" and eligible else "REJECTED"
            reason=(request.form.get("remarks") or "").strip()
            if final_decision=="REJECTED" and eligible and decision=="REJECTED":
                reason=reason or "Credit Officer rejected the otherwise eligible transaction."
            if final_decision=="REJECTED" and not eligible:
                reason=reason or "Credit approval rejected because available credit is insufficient."
            conn.execute("""UPDATE credit_approvals SET credit_limit=?,outstanding_balance=?,available_credit=?,eligibility_result=?,decision=?,approved_by=?,approval_date=?,remarks=? WHERE credit_approval_id=?""",(limit,outstanding,available,"ELIGIBLE" if eligible else "NOT ELIGIBLE",final_decision,user["user_id"],now_iso(),reason,id))
            new_status="APPROVED" if final_decision=="APPROVED" else "REJECTED"
            old_status=so["order_status"]
            require_transition(old_status,new_status)
            conn.execute("UPDATE sales_orders SET order_status=?,updated_date=? WHERE sales_order_id=?",(new_status,now_iso(),so["sales_order_id"]))
            add_audit(user,"CREDIT APPROVED" if new_status=="APPROVED" else "CREDIT REJECTED","CREDIT_APPROVAL",id,old_value=old_status,new_value={"decision":new_status,"available_credit":str(available),"reason":reason},conn=conn)
            if new_status=="APPROVED":
                conn.execute("UPDATE sales_orders SET order_status='READY FOR SHIPPING',updated_date=? WHERE sales_order_id=?",(now_iso(),so["sales_order_id"]))
                add_audit(user,"STATUS CHANGE","SALES_ORDER",so["sales_order_id"],old_value="APPROVED",new_value="READY FOR SHIPPING",conn=conn)
                notify_role("Warehouse / Inventory Staff",f"Credit approved. Sales Order {so['so_number']} is ready for shipping.","SALES_ORDER",so["sales_order_id"],conn=conn)
            else:
                notify_role("Salesperson",f"Credit approval rejected for Sales Order {so['so_number']}: {reason}","SALES_ORDER",so["sales_order_id"],exclude_user_id=user["user_id"],conn=conn)
        flash(f"Credit decision recorded as {final_decision}.","success")
    except ValueError as exc:
        log_block(user,"CREDIT DECISION BLOCKED","CREDIT_APPROVAL",id,str(exc)); flash(str(exc),"error")
    return redirect(url_for("credit_approval_detail",id=id))


@app.route("/manager-approvals")
@route_permission("manager_approval.view")
def manager_approvals():
    conn=get_connection()
    try:
        rows=conn.execute("""SELECT ma.*,so.so_number,so.grand_total,c.customer_name FROM manager_approvals ma JOIN sales_orders so ON so.sales_order_id=ma.entity_id JOIN customers c ON c.customer_id=so.customer_id WHERE ma.entity_type='SALES_ORDER' ORDER BY ma.manager_approval_id DESC""").fetchall()
        return render_template("manager_approvals.html",approvals=rows)
    finally: conn.close()


@app.route("/manager-approvals/<int:id>/decision", methods=["POST"])
@route_permission("manager_approval.decide")
def manager_approval_decision(id):
    user=get_current_user(); decision=request.form.get("decision")
    try:
        with transaction() as conn:
            ma=conn.execute("SELECT * FROM manager_approvals WHERE manager_approval_id=?",(id,)).fetchone()
            if not ma: abort(404)
            if ma["approval_status"]!="PENDING": raise ValueError("Manager approval has already been decided.")
            so=conn.execute("SELECT * FROM sales_orders WHERE sales_order_id=?",(ma["entity_id"],)).fetchone()
            if decision not in {"APPROVED","REJECTED"}: raise ValueError("Invalid approval decision.")
            conn.execute("UPDATE manager_approvals SET approval_status=?,approved_by=?,approval_date=?,remarks=? WHERE manager_approval_id=?",(decision,user["user_id"],now_iso(),request.form.get("remarks"),id))
            if decision=="APPROVED":
                conn.execute("UPDATE sales_orders SET discount_approval_status='APPROVED',updated_date=? WHERE sales_order_id=?",(now_iso(),ma["entity_id"]))
            else:
                conn.execute("UPDATE sales_orders SET discount_approval_status='REJECTED',updated_date=? WHERE sales_order_id=?",(now_iso(),ma["entity_id"]))
            add_audit(user,"MANAGER DISCOUNT " + decision,"MANAGER_APPROVAL",id,conn=conn)
            notify_role("Salesperson",f"Manager discount approval for {so['so_number']}: {decision}.","SALES_ORDER",so["sales_order_id"],exclude_user_id=user["user_id"],conn=conn)
        flash(f"Discount approval {decision.lower()}.","success")
    except ValueError as exc:
        log_block(user,"MANAGER DISCOUNT APPROVAL BLOCKED","MANAGER_APPROVAL",id,str(exc)); flash(str(exc),"error")
    return redirect(url_for("manager_approvals"))


@app.route("/shipping")
@route_permission("shipping.view")
def shipping():
    conn=get_connection()
    try:
        rows=conn.execute("""SELECT sh.*,so.so_number,c.customer_name,u.employee_name shipped_by_name FROM shippings sh JOIN sales_orders so ON so.sales_order_id=sh.sales_order_id JOIN customers c ON c.customer_id=so.customer_id JOIN users u ON u.user_id=sh.shipped_by ORDER BY sh.shipping_id DESC""").fetchall()
        ready=conn.execute("""SELECT so.*,c.customer_name FROM sales_orders so JOIN customers c ON c.customer_id=so.customer_id WHERE so.order_status IN ('READY FOR SHIPPING','PARTIALLY SHIPPED') ORDER BY so.sales_order_id DESC""").fetchall()
        return render_template("shipping.html",shippings=rows,ready_orders=ready)
    finally: conn.close()


@app.route("/shipping/new/<int:so_id>", methods=["GET","POST"])
@route_permission("shipping.create")
def shipping_create(so_id):
    user=get_current_user(); conn=get_connection()
    try:
        so=get_so_header(conn,so_id)
        if not so: abort(404)
        if so["order_status"] not in {"READY FOR SHIPPING","PARTIALLY SHIPPED"}:
            raise ValueError("Shipping is only available for eligible Sales Orders.")
        if so["sales_type"]=="CREDIT":
            ca=conn.execute("SELECT decision FROM credit_approvals WHERE sales_order_id=?",(so_id,)).fetchone()
            if not ca or ca["decision"]!="APPROVED": raise ValueError("Shipping cannot be processed until credit approval is completed.")
        lines=get_so_lines(conn,so_id)
        if request.method=="POST":
            try:
                quantities=request.form.getlist("ship_qty[]")
                if len(quantities)!=len(lines): raise ValueError("Invalid shipping request.")
                delivery=so["delivery_address"].strip()
                if not delivery: raise ValueError("Delivery information is missing.")
                parsed=[]
                for line, val in zip(lines, quantities):
                    qty=_parse_decimal(val or 0,"Shipment quantity")
                    if qty<0: raise ValueError("Shipment quantity cannot be negative.")
                    remaining=money(line["quantity"]) - money(line["shipped_qty"])
                    if qty>remaining: raise ValueError(f"{line['product_name']}: quantity shipped exceeds remaining order quantity ({remaining}).")
                    stock_row=conn.execute("SELECT COALESCE(SUM(quantity),0) qty FROM inventory_stock WHERE product_id=?",(line["product_id"],)).fetchone()
                    available=money(stock_row["qty"])
                    if qty>available: raise ValueError(f"Insufficient stock. Only {available} units of {line['product_name']} are currently available.")
                    if qty>0: parsed.append((line,qty,available))
                if not parsed: raise ValueError("At least one item must be shipped.")
                sh_num=generate_number(conn,"SH","shippings","shipping_number")
                row=conn.execute("INSERT INTO shippings(shipping_number,sales_order_id,shipping_date,delivery_address,shipping_status,shipped_by) VALUES(?,?,?,?, 'PENDING',?)",(sh_num,so_id,request.form.get("shipping_date") or date.today().isoformat(),delivery,user["user_id"]))
                ship_id=row.lastrowid
                # Build shipment; stock check and inventory movement are atomic in this transaction.
                for line,qty,available in parsed:
                    warehouse_id=_get_int("warehouse_id") or 1
                    stock_at_wh=money(conn.execute("SELECT COALESCE(quantity,0) q FROM inventory_stock WHERE product_id=? AND warehouse_id=?",(line["product_id"],warehouse_id)).fetchone()["q"])
                    if qty>stock_at_wh: raise ValueError(f"Insufficient stock in selected warehouse. Only {stock_at_wh} units available at this location.")
                    conn.execute("INSERT INTO shipping_details(shipping_id,sales_order_detail_id,product_id,quantity_shipped,unit_cost,warehouse_id) VALUES(?,?,?,?,?,?)",(ship_id,line["sales_order_detail_id"],line["product_id"],qty,money(conn.execute("SELECT standard_cost FROM products WHERE product_id=?",(line["product_id"],)).fetchone()["standard_cost"]),warehouse_id))
                    inventory_adjust(conn,line["product_id"],warehouse_id,-qty,user["user_id"],"SHIPMENT","SHIPPING",ship_id,reason=sh_num,unit_cost=money(conn.execute("SELECT standard_cost FROM products WHERE product_id=?",(line["product_id"],)).fetchone()["standard_cost"]))
                    # COGS entry is posted per product line through product mapping.
                    pa=conn.execute("SELECT * FROM product_accounts WHERE product_id=?",(line["product_id"],)).fetchone()
                    if pa:
                        amount=(qty*money(line["standard_cost"] if "standard_cost" in line.keys() else conn.execute("SELECT standard_cost FROM products WHERE product_id=?",(line["product_id"],)).fetchone()["standard_cost"])).quantize(Decimal("0.01"))
                        post_accounting_entry(conn,user["user_id"],"SHIPPING",ship_id,f"COGS recognition for {sh_num}",[(pa["cogs_account_id"],amount,0,sh_num),(pa["inventory_account_id"],0,amount,sh_num)])
                conn.execute("UPDATE shippings SET shipping_status='SHIPPED' WHERE shipping_id=?",(ship_id,))
                total_remaining=conn.execute("""SELECT SUM(sod.quantity-COALESCE((SELECT SUM(sd.quantity_shipped) FROM shipping_details sd JOIN shippings sh2 ON sh2.shipping_id=sd.shipping_id WHERE sd.sales_order_detail_id=sod.sales_order_detail_id AND sh2.shipping_status='SHIPPED'),0)) rem FROM sales_order_details sod WHERE sod.sales_order_id=?""",(so_id,)).fetchone()["rem"]
                new_status="FULLY SHIPPED" if money(total_remaining)<=0 else "PARTIALLY SHIPPED"
                old_status=so["order_status"]
                require_transition(old_status,new_status)
                conn.execute("UPDATE sales_orders SET order_status=?,updated_date=? WHERE sales_order_id=?",(new_status,now_iso(),so_id))
                add_audit(user,"SHIPPING CONFIRMED","SHIPPING",ship_id,old_value=old_status,new_value=new_status,conn=conn)
                notify_role("Accounting / Billing Staff",f"Shipping {sh_num} confirmed for {so['so_number']}. Invoice can be created for shipped goods.","SHIPPING",ship_id,conn=conn)
                conn.commit()
                flash(f"Shipping {sh_num} confirmed. Inventory updated automatically.","success")
                return redirect(url_for("shipping_detail",id=ship_id))
            except (ValueError, sqlite3.IntegrityError) as exc:
                conn.rollback(); log_block(user,"SHIPPING BLOCKED","SHIPPING",so_id,str(exc)); flash(str(exc),"error")
        warehouses=conn.execute("SELECT * FROM warehouses WHERE is_active=1").fetchall()
        return render_template("shipping_create.html",so=so,lines=lines,warehouses=warehouses)
    except ValueError as exc:
        conn.close(); log_block(user,"SHIPPING ACCESS BLOCKED","SHIPPING",so_id,str(exc)); flash(str(exc),"error"); return redirect(url_for("shipping"))
    finally:
        try: conn.close()
        except: pass


@app.route("/shipping/<int:id>")
@route_permission("shipping.view")
def shipping_detail(id):
    conn=get_connection()
    try:
        sh=conn.execute("""SELECT sh.*,so.so_number,so.sales_order_id,c.customer_name,c.customer_code,u.employee_id shipped_by_employee,u.employee_name shipped_by_name FROM shippings sh JOIN sales_orders so ON so.sales_order_id=sh.sales_order_id JOIN customers c ON c.customer_id=so.customer_id JOIN users u ON u.user_id=sh.shipped_by WHERE sh.shipping_id=?""",(id,)).fetchone()
        if not sh: abort(404)
        details=conn.execute("SELECT sd.*,p.product_name,p.product_code FROM shipping_details sd JOIN products p ON p.product_id=sd.product_id WHERE sd.shipping_id=?",(id,)).fetchall()
        invoice=conn.execute("SELECT * FROM invoices WHERE shipping_id=?",(id,)).fetchone()
        return render_template("shipping_detail.html",shipping=sh,details=details,invoice=invoice)
    finally: conn.close()


@app.route("/shipping/<int:id>/cancel",methods=["POST"])
@route_permission("shipping.cancel")
def shipping_cancel(id):
    user=get_current_user()
    try:
        with transaction() as conn:
            sh=conn.execute("SELECT * FROM shippings WHERE shipping_id=?",(id,)).fetchone()
            if not sh: abort(404)
            if sh["shipping_status"]!="SHIPPED": raise ValueError("Only confirmed shipments can be reversed/cancelled.")
            if conn.execute("SELECT 1 FROM invoices WHERE shipping_id=? AND invoice_status<>'CANCELLED'",(id,)).fetchone(): raise ValueError("Issued invoice exists. Reverse the billing transaction before cancelling shipment.")
            details=conn.execute("SELECT * FROM shipping_details WHERE shipping_id=?",(id,)).fetchall()
            for d in details:
                warehouse_id=d["warehouse_id"]
                inventory_adjust(conn,d["product_id"],warehouse_id,d["quantity_shipped"],user["user_id"],"ADJUSTMENT","SHIPPING_REVERSAL",id,reason="Shipping cancellation")
            conn.execute("UPDATE shippings SET shipping_status='CANCELLED' WHERE shipping_id=?",(id,))
            # Return order to READY/PARTIAL depending on remaining quantity.
            so_id=sh["sales_order_id"]
            total_remaining=conn.execute("""SELECT SUM(sod.quantity-COALESCE((SELECT SUM(sd.quantity_shipped) FROM shipping_details sd JOIN shippings sh2 ON sh2.shipping_id=sd.shipping_id WHERE sd.sales_order_detail_id=sod.sales_order_detail_id AND sh2.shipping_status='SHIPPED'),0)) rem FROM sales_order_details sod WHERE sod.sales_order_id=?""",(so_id,)).fetchone()["rem"]
            new_status="READY FOR SHIPPING" if money(total_remaining)==money(conn.execute("SELECT SUM(quantity) FROM sales_order_details WHERE sales_order_id=?",(so_id,)).fetchone()[0]) else "PARTIALLY SHIPPED"
            conn.execute("UPDATE sales_orders SET order_status=?,updated_date=? WHERE sales_order_id=?",(new_status,now_iso(),so_id))
            add_audit(user,"SHIPPING CANCELLED","SHIPPING",id,old_value="SHIPPED",new_value="CANCELLED",conn=conn)
        flash("Shipment cancelled and inventory reversed. The reversal remains auditable.","success")
    except ValueError as exc:
        log_block(user,"SHIPPING CANCEL BLOCKED","SHIPPING",id,str(exc)); flash(str(exc),"error")
    return redirect(url_for("shipping_detail",id=id))


@app.route("/invoices")
@route_permission("invoice.view")
def invoices():
    conn=get_connection()
    try:
        rows=conn.execute("SELECT i.*,c.customer_name,so.so_number,sh.shipping_number FROM invoices i JOIN customers c ON c.customer_id=i.customer_id JOIN sales_orders so ON so.sales_order_id=i.sales_order_id JOIN shippings sh ON sh.shipping_id=i.shipping_id ORDER BY i.invoice_id DESC").fetchall()
        eligible=conn.execute("SELECT sh.shipping_id,sh.shipping_number,so.so_number,c.customer_name FROM shippings sh JOIN sales_orders so ON so.sales_order_id=sh.sales_order_id JOIN customers c ON c.customer_id=so.customer_id LEFT JOIN invoices i ON i.shipping_id=sh.shipping_id WHERE sh.shipping_status='SHIPPED' AND i.invoice_id IS NULL ORDER BY sh.shipping_id DESC").fetchall()
        return render_template("invoices.html",invoices=rows,eligible=eligible)
    finally: conn.close()


@app.route("/invoices/new/<int:shipping_id>",methods=["GET","POST"])
@route_permission("invoice.create")
def invoice_create(shipping_id):
    user=get_current_user(); conn=get_connection()
    try:
        sh=conn.execute("""SELECT sh.*,so.so_number,so.sales_order_id,so.sales_type,c.customer_id,c.customer_name,c.customer_status,pt.term_name,pt.days FROM shippings sh JOIN sales_orders so ON so.sales_order_id=sh.sales_order_id JOIN customers c ON c.customer_id=so.customer_id JOIN payment_terms pt ON pt.payment_term_id=so.payment_term_id WHERE sh.shipping_id=?""",(shipping_id,)).fetchone()
        if not sh: abort(404)
        if sh["shipping_status"]!="SHIPPED": raise ValueError("Invoice cannot be issued because the goods have not been shipped.")
        if conn.execute("SELECT 1 FROM invoices WHERE shipping_id=?",(shipping_id,)).fetchone(): raise ValueError("This shipment has already been invoiced.")
        details=conn.execute("SELECT sd.*,sod.unit_price,sod.discount_percentage,p.product_name,p.product_code FROM shipping_details sd JOIN sales_order_details sod ON sod.sales_order_detail_id=sd.sales_order_detail_id JOIN products p ON p.product_id=sd.product_id WHERE sd.shipping_id=?",(shipping_id,)).fetchall()
        if not details: raise ValueError("No valid shipping details found.")
        amount=Decimal("0")
        for d in details:
            line=(money(d["quantity_shipped"])*money(d["unit_price"]))
            line_discount=line*money(d["discount_percentage"])/Decimal("100")
            amount+=(line-line_discount)
        shipping_cost = Decimal("0")
        # Shipping cost is applied once to the first/last shipment according to prototype billing policy.
        total_shipped_before=conn.execute("SELECT COALESCE(SUM(sd.quantity_shipped),0) q FROM shipping_details sd JOIN shippings sh2 ON sh2.shipping_id=sd.shipping_id WHERE sh2.sales_order_id=? AND sh2.shipping_status='SHIPPED' AND sh2.shipping_id<>?",(sh["sales_order_id"],shipping_id)).fetchone()["q"]
        if money(total_shipped_before)==0:
            so=conn.execute("SELECT shipping_cost FROM sales_orders WHERE sales_order_id=?",(sh["sales_order_id"],)).fetchone()
            shipping_cost=money(so["shipping_cost"])
        subtotal=amount
        tax=((subtotal+shipping_cost)*TAX_RATE).quantize(Decimal("0.01"))
        invoice_amount=(subtotal+shipping_cost+tax).quantize(Decimal("0.01"))
        invoice_date=date.today()
        due_date=invoice_date+timedelta(days=int(sh["days"]))
        if request.method=="POST":
            try:
                num=generate_number(conn,"INV","invoices","invoice_number")
                row=conn.execute("INSERT INTO invoices(invoice_number,sales_order_id,shipping_id,invoice_date,due_date,customer_id,invoice_amount,paid_amount,outstanding_amount,invoice_status,created_by) VALUES(?,?,?,?,?,?,?,?,?,'UNPAID',?)",(num,sh["sales_order_id"],shipping_id,invoice_date.isoformat(),due_date.isoformat(),sh["customer_id"],invoice_amount,0,invoice_amount,user["user_id"]))
                inv_id=row.lastrowid
                revenue_total=Decimal("0")
                for d in details:
                    line=(money(d["quantity_shipped"])*money(d["unit_price"]))
                    line_discount=line*money(d["discount_percentage"])/Decimal("100")
                    line_amount=(line-line_discount).quantize(Decimal("0.01"))
                    revenue_total += line_amount
                    conn.execute("INSERT INTO invoice_details(invoice_id,shipping_detail_id,product_id,quantity_invoiced,unit_price,discount_percentage,tax_amount,line_amount) VALUES(?,?,?,?,?,?,?,?)",(inv_id,d["shipping_detail_id"],d["product_id"],d["quantity_shipped"],d["unit_price"],d["discount_percentage"],(line_amount*TAX_RATE).quantize(Decimal("0.01")),line_amount))
                ar_acct=conn.execute("SELECT account_id FROM chart_of_accounts WHERE account_code='1100'").fetchone()[0]
                tax_acct=conn.execute("SELECT account_id FROM chart_of_accounts WHERE account_code='2200'").fetchone()[0]
                revenue_by_account={}
                for d in details:
                    pa=conn.execute("SELECT sales_account_id FROM product_accounts WHERE product_id=?",(d["product_id"],)).fetchone()
                    if not pa:
                        raise ValueError("Product/account mapping is missing; invoice cannot be issued.")
                    line=(money(d["quantity_shipped"])*money(d["unit_price"]))
                    line_discount=line*money(d["discount_percentage"])/Decimal("100")
                    line_amount=(line-line_discount).quantize(Decimal("0.01"))
                    revenue_by_account[pa["sales_account_id"]]=revenue_by_account.get(pa["sales_account_id"],Decimal("0"))+line_amount
                if shipping_cost:
                    # Prototype policy: shipping income is classified to the first mapped sales account.
                    first_acct=next(iter(revenue_by_account),None)
                    if first_acct is None:
                        raise ValueError("No sales account mapping found for invoice lines.")
                    revenue_by_account[first_acct]+=shipping_cost
                revenue_lines=[(acct,0,amt,num) for acct,amt in revenue_by_account.items() if money(amt)>0]
                post_accounting_entry(conn,user["user_id"],"INVOICE",inv_id,f"AR and revenue posting for {num}",[(ar_acct,invoice_amount,0,num)]+revenue_lines+[(tax_acct,0,tax,num)])
                add_audit(user,"INVOICE ISSUED","INVOICE",inv_id,new_value={"invoice_number":num,"amount":str(invoice_amount)},conn=conn)
                notify_role("Cashier",f"Invoice {num} has been issued and is ready for payment.","INVOICE",inv_id,conn=conn)
                conn.commit(); flash(f"Invoice {num} issued. Due date: {due_date:%d %B %Y}.","success"); return redirect(url_for("invoice_detail",id=inv_id))
            except (ValueError,sqlite3.IntegrityError) as exc:
                conn.rollback(); log_block(user,"INVOICE CREATION BLOCKED","INVOICE",shipping_id,str(exc)); flash(str(exc),"error")
        return render_template("invoice_create.html",shipping=sh,details=details,subtotal=subtotal,shipping_cost=shipping_cost,tax=tax,invoice_amount=invoice_amount,invoice_date=invoice_date,due_date=due_date)
    except ValueError as exc:
        conn.close(); log_block(user,"INVOICE CREATION BLOCKED","INVOICE",shipping_id,str(exc)); flash(str(exc),"error"); return redirect(url_for("invoices"))
    finally:
        try: conn.close()
        except: pass


@app.route("/invoices/<int:id>")
@route_permission("invoice.view")
def invoice_detail(id):
    conn=get_connection()
    try:
        inv=conn.execute("SELECT i.*,c.customer_name,c.customer_code,c.billing_address,so.so_number,sh.shipping_number FROM invoices i JOIN customers c ON c.customer_id=i.customer_id JOIN sales_orders so ON so.sales_order_id=i.sales_order_id JOIN shippings sh ON sh.shipping_id=i.shipping_id WHERE i.invoice_id=?",(id,)).fetchone()
        if not inv: abort(404)
        details=conn.execute("SELECT id.*,p.product_name,p.product_code FROM invoice_details id JOIN products p ON p.product_id=id.product_id WHERE id.invoice_id=?",(id,)).fetchall()
        receipts=conn.execute("SELECT * FROM cash_receipts WHERE invoice_id=? ORDER BY receipt_id",(id,)).fetchall()
        update_invoice_status(conn,id); conn.commit()
        inv=conn.execute("SELECT i.*,c.customer_name,c.customer_code,c.billing_address,so.so_number,sh.shipping_number FROM invoices i JOIN customers c ON c.customer_id=i.customer_id JOIN sales_orders so ON so.sales_order_id=i.sales_order_id JOIN shippings sh ON sh.shipping_id=i.shipping_id WHERE i.invoice_id=?",(id,)).fetchone()
        return render_template("invoice_detail.html",invoice=inv,details=details,receipts=receipts)
    finally: conn.close()


@app.route("/cash-receipts")
@route_permission("cash_receipt.view")
def cash_receipts():
    conn=get_connection()
    try:
        rows=conn.execute("SELECT cr.*,i.invoice_number,c.customer_name FROM cash_receipts cr JOIN invoices i ON i.invoice_id=cr.invoice_id JOIN customers c ON c.customer_id=i.customer_id ORDER BY cr.receipt_id DESC").fetchall()
        outstanding=conn.execute("SELECT i.*,c.customer_name FROM invoices i JOIN customers c ON c.customer_id=i.customer_id WHERE i.invoice_status IN ('UNPAID','PARTIAL') ORDER BY i.due_date").fetchall()
        return render_template("cash_receipts.html",receipts=rows,outstanding=outstanding)
    finally: conn.close()


@app.route("/cash-receipts/new/<int:invoice_id>",methods=["GET","POST"])
@route_permission("cash_receipt.create")
def cash_receipt_create(invoice_id):
    user=get_current_user(); conn=get_connection()
    try:
        inv=conn.execute("SELECT i.*,c.customer_name,c.customer_code FROM invoices i JOIN customers c ON c.customer_id=i.customer_id WHERE i.invoice_id=?",(invoice_id,)).fetchone()
        if not inv: abort(404)
        update_invoice_status(conn,invoice_id); conn.commit()
        inv=conn.execute("SELECT i.*,c.customer_name,c.customer_code FROM invoices i JOIN customers c ON c.customer_id=i.customer_id WHERE i.invoice_id=?",(invoice_id,)).fetchone()
        if inv["invoice_status"]=="CANCELLED": raise ValueError("Invoice is cancelled and cannot receive payment.")
        if inv["invoice_status"]=="PAID": raise ValueError("Invoice is already fully paid.")
        if request.method=="POST":
            try:
                amount=_parse_decimal(request.form.get("amount"),"Payment amount")
                if amount<=0: raise ValueError("Payment amount must be greater than 0.")
                if amount>money(inv["outstanding_amount"]): raise ValueError("Payment exceeds the remaining invoice balance.")
                num=generate_number(conn,"RC","cash_receipts","receipt_number")
                row=conn.execute("INSERT INTO cash_receipts(receipt_number,invoice_id,receipt_date,amount,payment_method,bank_reference,received_by,remarks) VALUES(?,?,?,?,?,?,?,?)",(num,invoice_id,request.form.get("receipt_date") or date.today().isoformat(),amount,request.form.get("payment_method"),request.form.get("bank_reference"),user["user_id"],request.form.get("remarks")))
                receipt_id=row.lastrowid
                balance=update_invoice_status(conn,invoice_id)
                cash_acct=conn.execute("SELECT account_id FROM chart_of_accounts WHERE account_code='1010'").fetchone()[0]
                ar_acct=conn.execute("SELECT account_id FROM chart_of_accounts WHERE account_code='1100'").fetchone()[0]
                post_accounting_entry(conn,user["user_id"],"CASH_RECEIPT",receipt_id,f"Cash receipt {num}",[(cash_acct,amount,0,num),(ar_acct,0,amount,num)])
                add_audit(user,"CASH RECEIPT CREATED","CASH_RECEIPT",receipt_id,new_value={"receipt_number":num,"invoice_id":invoice_id,"amount":str(amount)},conn=conn)
                notify_role("Accounting / Billing Staff",f"Payment {num} recorded for invoice {inv['invoice_number']}. Invoice is now {balance['status']}.","CASH_RECEIPT",receipt_id,conn=conn)
                conn.commit(); flash(f"Receipt {num} recorded. Invoice status: {balance['status']}.","success"); return redirect(url_for("cash_receipt_detail",id=receipt_id))
            except (ValueError,sqlite3.IntegrityError) as exc:
                conn.rollback(); log_block(user,"CASH RECEIPT BLOCKED","CASH_RECEIPT",invoice_id,str(exc)); flash(str(exc),"error")
        return render_template("cash_receipt_create.html",invoice=inv)
    except ValueError as exc:
        conn.close(); log_block(user,"CASH RECEIPT ACCESS BLOCKED","CASH_RECEIPT",invoice_id,str(exc)); flash(str(exc),"error"); return redirect(url_for("cash_receipts"))
    finally:
        try: conn.close()
        except: pass


@app.route("/cash-receipts/<int:id>")
@route_permission("cash_receipt.view")
def cash_receipt_detail(id):
    conn=get_connection()
    try:
        cr=conn.execute("SELECT cr.*,i.invoice_number,i.invoice_amount,i.outstanding_amount,c.customer_name,c.customer_code,u.employee_id,u.employee_name FROM cash_receipts cr JOIN invoices i ON i.invoice_id=cr.invoice_id JOIN customers c ON c.customer_id=i.customer_id JOIN users u ON u.user_id=cr.received_by WHERE cr.receipt_id=?",(id,)).fetchone()
        if not cr: abort(404)
        return render_template("cash_receipt_detail.html",receipt=cr)
    finally: conn.close()


@app.route("/ar-ap")
@route_permission("ar.view")
def ar_ap():
    conn=get_connection()
    try:
        rows=conn.execute("""SELECT i.*,c.customer_name,COALESCE((SELECT SUM(cr.amount) FROM cash_receipts cr WHERE cr.invoice_id=i.invoice_id AND cr.status='POSTED'),0) calc_paid,
                       CASE WHEN date(i.due_date)<date('now') AND i.outstanding_amount>0 THEN 1 ELSE 0 END overdue
                       FROM invoices i JOIN customers c ON c.customer_id=i.customer_id WHERE i.invoice_status<>'CANCELLED' ORDER BY i.due_date""").fetchall()
        credit_notes=conn.execute("SELECT cn.*,c.customer_name,i.invoice_number FROM credit_notes cn JOIN customers c ON c.customer_id=cn.customer_id LEFT JOIN invoices i ON i.invoice_id=cn.invoice_id ORDER BY cn.credit_note_id DESC").fetchall()
        return render_template("ar_ap.html",invoices=rows,credit_notes=credit_notes)
    finally: conn.close()


@app.route("/ar-ap/credit-notes/new",methods=["GET","POST"])
@route_permission("credit_note.create")
def credit_note_create():
    user=get_current_user(); conn=get_connection()
    if request.method=="POST":
        try:
            customer_id=_get_int("customer_id"); invoice_id=_get_int("invoice_id")
            amount=_parse_decimal(request.form.get("amount"),"Credit note amount")
            reason=(request.form.get("reason") or "").strip()
            if amount<=0 or not reason: raise ValueError("Amount must be > 0 and reason is required.")
            if invoice_id:
                inv=conn.execute("SELECT * FROM invoices WHERE invoice_id=? AND customer_id=?",(invoice_id,customer_id)).fetchone()
                if not inv: raise ValueError("Invoice does not match the selected customer.")
                update_invoice_status(conn,invoice_id)
                inv=conn.execute("SELECT * FROM invoices WHERE invoice_id=?",(invoice_id,)).fetchone()
                if amount>money(inv["outstanding_amount"]): raise ValueError("Credit note cannot exceed the invoice outstanding balance.")
            num=generate_simple_number(conn,"CN","credit_notes","credit_note_number")
            row=conn.execute("INSERT INTO credit_notes(credit_note_number,customer_id,invoice_id,amount,reason,created_by) VALUES(?,?,?,?,?,?)",(num,customer_id,invoice_id,amount,reason,user["user_id"]))
            cn_id=row.lastrowid
            if invoice_id:
                update_invoice_status(conn,invoice_id)
            add_audit(user,"AR CREDIT NOTE CREATED","AR",cn_id,conn=conn)
            conn.commit(); flash(f"Credit Note {num} created.","success"); return redirect(url_for("ar_ap"))
        except (ValueError,sqlite3.IntegrityError) as exc:
            conn.rollback(); log_block(user,"AR CREDIT NOTE BLOCKED","AR",None,str(exc)); flash(str(exc),"error")
    customers_list=conn.execute("SELECT customer_id,customer_code,customer_name FROM customers WHERE customer_status='ACTIVE' ORDER BY customer_name").fetchall()
    invoices_list=conn.execute("SELECT invoice_id,invoice_number,customer_id,outstanding_amount FROM invoices WHERE invoice_status IN ('UNPAID','PARTIAL') ORDER BY invoice_id DESC").fetchall()
    conn.close()
    return render_template("credit_note_create.html",customers=customers_list,invoices=invoices_list)


@app.route("/inventory")
@route_permission("inventory.view")
def inventory():
    conn=get_connection()
    try:
        rows=conn.execute("""SELECT p.product_id,p.product_code,p.product_name,p.category,p.standard_cost,p.available_stock,
                      (p.available_stock*p.standard_cost) stock_value,p.product_status
                      FROM products p ORDER BY p.product_name""").fetchall()
        movements=conn.execute("""SELECT im.*,p.product_name,w.warehouse_name,u.employee_name FROM inventory_movements im JOIN products p ON p.product_id=im.product_id JOIN warehouses w ON w.warehouse_id=im.warehouse_id JOIN users u ON u.user_id=im.created_by ORDER BY im.movement_id DESC LIMIT 30""").fetchall()
        warehouses=conn.execute("SELECT * FROM warehouses WHERE is_active=1").fetchall()
        return render_template("inventory.html",products=rows,movements=movements,warehouses=warehouses)
    finally: conn.close()


@app.route("/inventory/grn/new",methods=["GET","POST"])
@route_permission("inventory.receive")
def grn_create():
    user=get_current_user(); conn=get_connection()
    if request.method=="POST":
        try:
            product_id=_get_int("product_id"); warehouse_id=_get_int("warehouse_id"); qty=_parse_decimal(request.form.get("quantity"),"Quantity")
            cost=_parse_decimal(request.form.get("unit_cost"),"Unit cost")
            if qty<=0 or cost<0: raise ValueError("Quantity must be > 0 and unit cost cannot be negative.")
            validate_product_active(conn,product_id)
            num=generate_number(conn,"GRN","goods_receipts","grn_number")
            row=conn.execute("INSERT INTO goods_receipts(grn_number,receiving_date,reference_purchase_order,product_id,quantity_received,warehouse_id,unit_cost,status,received_by) VALUES(?,?,?,?,?,?,?,'CONFIRMED',?)",(num,request.form.get("receiving_date") or date.today().isoformat(),request.form.get("reference_purchase_order"),product_id,qty,warehouse_id,cost,user["user_id"]))
            grn_id=row.lastrowid
            inventory_adjust(conn,product_id,warehouse_id,qty,user["user_id"],"RECEIPT","GRN",grn_id,reason="Goods Receipt",unit_cost=cost)
            pa=conn.execute("SELECT inventory_account_id FROM product_accounts WHERE product_id=?",(product_id,)).fetchone()
            ap=conn.execute("SELECT account_id FROM chart_of_accounts WHERE account_code='2100'").fetchone()
            if pa and ap:
                val=(qty*cost).quantize(Decimal("0.01")); post_accounting_entry(conn,user["user_id"],"GRN",grn_id,f"Inventory receipt {num}",[(pa["inventory_account_id"],val,0,num),(ap["account_id"],0,val,num)])
            add_audit(user,"GRN CONFIRMED","INVENTORY",grn_id,conn=conn)
            conn.commit(); flash(f"GRN {num} confirmed. Inventory increased by {qty}.","success"); return redirect(url_for("inventory"))
        except (ValueError,sqlite3.IntegrityError) as exc:
            conn.rollback(); log_block(user,"GRN BLOCKED","INVENTORY",None,str(exc)); flash(str(exc),"error")
    products_list=conn.execute("SELECT * FROM products WHERE product_status='ACTIVE' ORDER BY product_name").fetchall(); warehouses=conn.execute("SELECT * FROM warehouses WHERE is_active=1").fetchall(); conn.close()
    return render_template("grn_create.html",products=products_list,warehouses=warehouses)


@app.route("/inventory/transfer",methods=["POST"])
@route_permission("inventory.transfer")
def stock_transfer():
    user=get_current_user(); conn=get_connection()
    try:
        product_id=_get_int("product_id"); qty=_parse_decimal(request.form.get("quantity"),"Transfer quantity"); source=_get_int("source_warehouse_id"); dest=_get_int("destination_warehouse_id")
        if qty<=0: raise ValueError("Transfer quantity must be greater than 0.")
        if source==dest: raise ValueError("Source and destination must be different.")
        src=money(conn.execute("SELECT COALESCE(quantity,0) q FROM inventory_stock WHERE product_id=? AND warehouse_id=?",(product_id,source)).fetchone()["q"])
        if qty>src: raise ValueError("Insufficient stock at source location.")
        with transaction() as tconn:
            num=generate_number(tconn,"ST","stock_transfers","transfer_number")
            row=tconn.execute("INSERT INTO stock_transfers(transfer_number,product_id,quantity,source_warehouse_id,destination_warehouse_id,transfer_date,created_by) VALUES(?,?,?,?,?,?,?)",(num,product_id,qty,source,dest,date.today().isoformat(),user["user_id"]))
            tid=row.lastrowid
            product=tconn.execute("SELECT standard_cost FROM products WHERE product_id=?",(product_id,)).fetchone(); cost=money(product["standard_cost"])
            inventory_adjust(tconn,product_id,source,-qty,user["user_id"],"TRANSFER_OUT","TRANSFER",tid,reason=num,unit_cost=cost)
            inventory_adjust(tconn,product_id,dest,qty,user["user_id"],"TRANSFER_IN","TRANSFER",tid,reason=num,unit_cost=cost)
            add_audit(user,"STOCK TRANSFER","INVENTORY",tid,new_value={"quantity":str(qty),"source":source,"destination":dest},conn=tconn)
        flash(f"Stock transfer {num} completed.","success")
    except (ValueError,sqlite3.IntegrityError) as exc:
        log_block(user,"STOCK TRANSFER BLOCKED","INVENTORY",None,str(exc)); flash(str(exc),"error")
    finally: conn.close()
    return redirect(url_for("inventory"))


@app.route("/inventory/adjust",methods=["POST"])
@route_permission("inventory.adjust")
def inventory_adjust_route():
    user=get_current_user(); conn=get_connection()
    try:
        product_id=_get_int("product_id"); warehouse_id=_get_int("warehouse_id"); physical=_parse_decimal(request.form.get("physical_quantity"),"Physical quantity"); reason=(request.form.get("reason") or "").strip()
        if physical<0: raise ValueError("Physical quantity cannot be negative.")
        if not reason: raise ValueError("Adjustment reason is required.")
        current=money(conn.execute("SELECT COALESCE(quantity,0) q FROM inventory_stock WHERE product_id=? AND warehouse_id=?",(product_id,warehouse_id)).fetchone()["q"])
        delta=physical-current
        with transaction() as tconn:
            num=generate_number(tconn,"ADJ","inventory_adjustments","adjustment_number")
            row=tconn.execute("INSERT INTO inventory_adjustments(adjustment_number,product_id,warehouse_id,system_quantity,physical_quantity,adjustment_quantity,reason,adjusted_by,adjustment_date) VALUES(?,?,?,?,?,?,?,?,?)",(num,product_id,warehouse_id,current,physical,delta,reason,user["user_id"],date.today().isoformat()))
            adj_id=row.lastrowid
            inventory_adjust(tconn,product_id,warehouse_id,delta,user["user_id"],"ADJUSTMENT","INVENTORY_ADJUSTMENT",adj_id,reason=reason,unit_cost=money(tconn.execute("SELECT standard_cost FROM products WHERE product_id=?",(product_id,)).fetchone()["standard_cost"]))
            add_audit(user,"INVENTORY ADJUSTMENT","INVENTORY",adj_id,old_value=str(current),new_value=str(physical),conn=tconn)
        flash(f"Inventory adjustment {num} posted ({delta:+}).", "success")
    except (ValueError,sqlite3.IntegrityError) as exc:
        log_block(user,"INVENTORY ADJUSTMENT BLOCKED","INVENTORY",None,str(exc)); flash(str(exc),"error")
    finally: conn.close()
    return redirect(url_for("inventory"))


@app.route("/bank-reconciliation")
@route_permission("bank_reconciliation.view")
def bank_reconciliation():
    conn=get_connection()
    try:
        rows=conn.execute("""SELECT bt.*,br.reconciliation_id,br.reconciliation_status,br.difference_amount,br.reason,cr.receipt_number,cr.amount receipt_amount,i.invoice_number
                          FROM bank_transactions bt LEFT JOIN bank_reconciliations br ON br.bank_transaction_id=bt.bank_transaction_id
                          LEFT JOIN cash_receipts cr ON cr.receipt_id=br.cash_receipt_id LEFT JOIN invoices i ON i.invoice_id=cr.invoice_id ORDER BY bt.bank_transaction_id DESC""").fetchall()
        receipts=conn.execute("""SELECT cr.*,i.invoice_number,c.customer_name FROM cash_receipts cr JOIN invoices i ON i.invoice_id=cr.invoice_id JOIN customers c ON c.customer_id=i.customer_id WHERE cr.status='POSTED' ORDER BY cr.receipt_id DESC""").fetchall()
        return render_template("bank_reconciliation.html",transactions=rows,receipts=receipts)
    finally: conn.close()


@app.route("/bank-reconciliation/reconcile/<int:id>",methods=["POST"])
@route_permission("bank_reconciliation.reconcile")
def bank_reconcile_action(id):
    user=get_current_user()
    try:
        with transaction() as conn:
            bt=conn.execute("SELECT * FROM bank_transactions WHERE bank_transaction_id=?",(id,)).fetchone()
            if not bt: abort(404)
            receipt_id=_get_int("receipt_id")
            cr=conn.execute("SELECT * FROM cash_receipts WHERE receipt_id=?",(receipt_id,)).fetchone() if receipt_id else None
            if not cr: raise ValueError("A valid Cash Receipt must be selected.")
            diff=(money(bt["amount"])-money(cr["amount"])).quantize(Decimal("0.01"))
            status="RECONCILED" if diff==0 and bt["transaction_type"]=="INCOMING" else "EXCEPTION"
            reason=None if status=="RECONCILED" else (request.form.get("reason") or "Amount/type mismatch requires investigation.")
            existing=conn.execute("SELECT reconciliation_id FROM bank_reconciliations WHERE bank_transaction_id=?",(id,)).fetchone()
            if existing:
                conn.execute("UPDATE bank_reconciliations SET cash_receipt_id=?,reconciliation_status=?,difference_amount=?,reconciled_by=?,reconciled_at=?,reason=? WHERE bank_transaction_id=?",(receipt_id,status,diff,user["user_id"],now_iso(),reason,id))
            else:
                conn.execute("INSERT INTO bank_reconciliations(bank_transaction_id,cash_receipt_id,reconciliation_status,difference_amount,reconciled_by,reconciled_at,reason) VALUES(?,?,?,?,?,?,?)",(id,receipt_id,status,diff,user["user_id"],now_iso(),reason))
            add_audit(user,"BANK RECONCILIATION","BANK_RECONCILIATION",id,new_value={"status":status,"difference":str(diff)},conn=conn)
        flash(f"Bank transaction marked {status.lower()}.","success")
    except ValueError as exc:
        log_block(user,"BANK RECONCILIATION BLOCKED","BANK_RECONCILIATION",id,str(exc)); flash(str(exc),"error")
    return redirect(url_for("bank_reconciliation"))


@app.route("/bank-reconciliation/seed-demo",methods=["POST"])
@route_permission("bank_reconciliation.manage")
def bank_seed_demo():
    user=get_current_user()
    with transaction() as conn:
        conn.execute("INSERT INTO bank_transactions(transaction_date,amount,transaction_type,reference,description) VALUES(?,?,?,?,?)",(date.today().isoformat(),_parse_decimal(request.form.get("amount"),"Amount"),"INCOMING",request.form.get("reference"),request.form.get("description")))
        bt=conn.execute("SELECT last_insert_rowid() x").fetchone()["x"]
        conn.execute("INSERT INTO bank_reconciliations(bank_transaction_id,reconciliation_status) VALUES(?,'UNRECONCILED')",(bt,))
        add_audit(user,"BANK TRANSACTION CREATED","BANK_RECONCILIATION",bt,conn=conn)
    flash("Demo bank transaction created as UNRECONCILED.","success")
    return redirect(url_for("bank_reconciliation"))


@app.route("/reports")
@route_permission("report.view")
def reports():
    conn=get_connection()
    try:
        f=request.args.get("filter") or ""
        status=request.args.get("status") or ""
        sales_type=request.args.get("sales_type") or ""
        customer_id=request.args.get("customer_id") or ""
        product_id=request.args.get("product_id") or ""
        so_sql="""SELECT so.so_number,so.order_date,c.customer_name,u.employee_name salesperson,so.sales_type,so.order_status,so.grand_total amount FROM sales_orders so JOIN customers c ON c.customer_id=so.customer_id JOIN users u ON u.user_id=so.salesperson_id WHERE 1=1"""
        params=[]
        if status: so_sql += " AND so.order_status=?"; params.append(status)
        if sales_type: so_sql += " AND so.sales_type=?"; params.append(sales_type)
        if customer_id: so_sql += " AND so.customer_id=?"; params.append(customer_id)
        if f: so_sql += " AND so.order_date>=?"; params.append(f)
        sales_orders_r=conn.execute(so_sql+" ORDER BY so.order_date DESC",params).fetchall()
        ar=conn.execute("""SELECT i.invoice_number,c.customer_name,i.invoice_date,i.due_date,i.invoice_amount,i.paid_amount,i.outstanding_amount,i.invoice_status,CASE WHEN date(i.due_date)<date('now') AND i.outstanding_amount>0 THEN 'OVERDUE' ELSE '' END overdue FROM invoices i JOIN customers c ON c.customer_id=i.customer_id WHERE i.invoice_status<>'CANCELLED' ORDER BY i.due_date""").fetchall()
        prod_sql="""SELECT p.product_name,SUM(sd.quantity_shipped) quantity_sold,SUM(sd.quantity_shipped*sod.unit_price) sales_amount,SUM((sd.quantity_shipped*sod.unit_price)*(sod.discount_percentage/100.0)) discount,SUM((sd.quantity_shipped*sod.unit_price)*(1-sod.discount_percentage/100.0)) net_sales FROM shipping_details sd JOIN shippings sh ON sh.shipping_id=sd.shipping_id AND sh.shipping_status='SHIPPED' JOIN sales_order_details sod ON sod.sales_order_detail_id=sd.sales_order_detail_id JOIN products p ON p.product_id=sd.product_id WHERE 1=1"""
        pparams=[]
        if product_id: prod_sql += " AND p.product_id=?"; pparams.append(product_id)
        sales_by_product=conn.execute(prod_sql+" GROUP BY p.product_id ORDER BY net_sales DESC",pparams).fetchall()
        customer_sales=conn.execute("""SELECT c.customer_name,COUNT(DISTINCT so.sales_order_id) number_of_orders,COALESCE(SUM(so.grand_total),0) total_sales,COALESCE(SUM((SELECT SUM(cr.amount) FROM cash_receipts cr JOIN invoices i2 ON i2.invoice_id=cr.invoice_id WHERE i2.customer_id=c.customer_id AND cr.status='POSTED')),0) total_paid,COALESCE(SUM(i.outstanding_amount),0) outstanding_balance FROM customers c LEFT JOIN sales_orders so ON so.customer_id=c.customer_id LEFT JOIN invoices i ON i.customer_id=c.customer_id GROUP BY c.customer_id ORDER BY total_sales DESC""").fetchall()
        credit=conn.execute("SELECT so.so_number,c.customer_name,ca.order_amount,ca.credit_limit,ca.outstanding_balance,ca.available_credit,ca.decision,u.employee_name approved_by FROM credit_approvals ca JOIN sales_orders so ON so.sales_order_id=ca.sales_order_id JOIN customers c ON c.customer_id=ca.customer_id LEFT JOIN users u ON u.user_id=ca.approved_by ORDER BY ca.credit_approval_id DESC").fetchall()
        shipping_r=conn.execute("SELECT sh.shipping_number,so.so_number,c.customer_name,p.product_name,sd.quantity_shipped quantity,sh.shipping_status FROM shipping_details sd JOIN shippings sh ON sh.shipping_id=sd.shipping_id JOIN sales_orders so ON so.sales_order_id=sh.sales_order_id JOIN customers c ON c.customer_id=so.customer_id JOIN products p ON p.product_id=sd.product_id ORDER BY sh.shipping_id DESC").fetchall()
        bank=conn.execute("SELECT bt.bank_transaction_id,bt.transaction_date,bt.amount,bt.reference,cr.receipt_number matched_document,COALESCE(br.reconciliation_status,'UNRECONCILED') reconciliation_status FROM bank_transactions bt LEFT JOIN bank_reconciliations br ON br.bank_transaction_id=bt.bank_transaction_id LEFT JOIN cash_receipts cr ON cr.receipt_id=br.cash_receipt_id ORDER BY bt.bank_transaction_id DESC").fetchall()
        inventory_r=conn.execute("SELECT p.product_name,p.category,p.available_stock stock_quantity,(p.available_stock*p.standard_cost) stock_value,w.warehouse_name location,p.product_status status FROM products p LEFT JOIN inventory_stock s ON s.product_id=p.product_id LEFT JOIN warehouses w ON w.warehouse_id=s.warehouse_id ORDER BY p.product_name").fetchall()
        customers_list=conn.execute("SELECT customer_id,customer_name FROM customers ORDER BY customer_name").fetchall(); products_list=conn.execute("SELECT product_id,product_name FROM products ORDER BY product_name").fetchall()
        return render_template("reports.html",sales_orders=sales_orders_r,ar=ar,sales_by_product=sales_by_product,customer_sales=customer_sales,credit=credit,shipping=shipping_r,bank=bank,inventory=inventory_r,customers=customers_list,products=products_list)
    finally: conn.close()


@app.route("/audit-logs")
@route_permission("audit.view")
def audit_logs():
    conn=get_connection()
    try:
        rows=conn.execute("SELECT * FROM audit_logs ORDER BY audit_id DESC LIMIT 500").fetchall()
        return render_template("audit_logs.html",logs=rows)
    finally: conn.close()


@app.route("/users")
@route_permission("user.manage")
def users():
    conn=get_connection()
    try:
        rows=conn.execute("SELECT u.*,r.role_name FROM users u JOIN roles r ON r.role_id=u.role_id ORDER BY u.user_id").fetchall(); roles=conn.execute("SELECT * FROM roles ORDER BY role_id").fetchall()
        permissions=conn.execute("SELECT * FROM permissions ORDER BY permission_code").fetchall()
        assignments=conn.execute("SELECT role_id,permission_id FROM role_permissions").fetchall()
        assigned={(a["role_id"],a["permission_id"]) for a in assignments}
        return render_template("users.html",users=rows,roles=roles,permissions=permissions,assigned=assigned)
    finally: conn.close()


@app.route("/roles/<int:role_id>/permissions",methods=["POST"])
@route_permission("user.manage")
def role_permissions_update(role_id):
    actor=get_current_user()
    try:
        with transaction() as conn:
            role=conn.execute("SELECT role_name FROM roles WHERE role_id=?",(role_id,)).fetchone()
            if not role: abort(404)
            selected={int(x) for x in request.form.getlist("permission_id[]") if x.isdigit()}
            valid={r["permission_id"] for r in conn.execute("SELECT permission_id FROM permissions").fetchall()}
            selected &= valid
            conn.execute("DELETE FROM role_permissions WHERE role_id=?",(role_id,))
            for pid in selected: conn.execute("INSERT INTO role_permissions(role_id,permission_id) VALUES(?,?)",(role_id,pid))
            add_audit(actor,"ROLE PERMISSIONS UPDATED","USER",role_id,new_value={"permission_count":len(selected)},conn=conn)
        flash(f"Permissions updated for {role['role_name']}.","success")
    except sqlite3.IntegrityError as exc:
        log_block(actor,"ROLE PERMISSION UPDATE BLOCKED","USER",role_id,str(exc)); flash("Permission update failed.","error")
    return redirect(url_for("users"))


@app.route("/users/new",methods=["POST"])
@route_permission("user.manage")
def user_create():
    actor=get_current_user()
    try:
        with transaction() as conn:
            role_id=_get_int("role_id")
            employee_id=(request.form.get("employee_id") or "").strip(); name=(request.form.get("employee_name") or "").strip(); password=request.form.get("password") or ""
            if not employee_id or not name or not password: raise ValueError("Employee ID, name, and password are required.")
            conn.execute("INSERT INTO users(employee_id,employee_name,username,password_hash,role_id) VALUES(?,?,?,?,?)",(employee_id,name,employee_id,hash_password(password),role_id))
            uid=conn.execute("SELECT last_insert_rowid() x").fetchone()["x"]
            add_audit(actor,"USER CREATED","USER",uid,conn=conn)
        flash("User created with a password hash.","success")
    except (ValueError,sqlite3.IntegrityError) as exc:
        log_block(actor,"USER CREATE BLOCKED","USER",None,str(exc)); flash("Unable to create user: "+str(exc),"error")
    return redirect(url_for("users"))


@app.route("/notifications/<int:id>/read",methods=["POST"])
@login_required
def notification_read(id):
    user=get_current_user()
    with transaction() as conn:
        conn.execute("UPDATE notifications SET is_read=1 WHERE notification_id=? AND user_id=?",(id,user["user_id"]))
    return redirect(request.referrer or url_for("dashboard"))


@app.route("/notifications/read-all",methods=["POST"])
@login_required
def notifications_read_all():
    user=get_current_user()
    with transaction() as conn:
        conn.execute("UPDATE notifications SET is_read=1 WHERE user_id=?",(user["user_id"],))
    return redirect(request.referrer or url_for("dashboard"))


@app.route("/api/customers/<int:id>")
@route_permission("customer.view")
def api_customer(id):
    conn=get_connection()
    try:
        c=conn.execute("""SELECT c.*,pt.term_name,pt.days FROM customers c JOIN payment_terms pt ON pt.payment_term_id=c.payment_term_id WHERE c.customer_id=?""",(id,)).fetchone()
        if not c: return jsonify({"error":"Customer not found"}),404
        return jsonify(dict(c))
    finally: conn.close()


@app.route("/api/products/<int:id>")
@route_permission("product.view")
def api_product(id):
    conn=get_connection()
    try:
        p=conn.execute("SELECT * FROM products WHERE product_id=?",(id,)).fetchone()
        if not p: return jsonify({"error":"Product not found"}),404
        return jsonify(dict(p))
    finally: conn.close()


@app.errorhandler(ValueError)
def handle_value_error(exc):
    # User-facing business rule errors are handled in transaction routes. This catches any unhandled ones.
    flash(str(exc),"error")
    return redirect(request.referrer or url_for("dashboard"))


@app.errorhandler(403)
def forbidden(_):
    return render_template("access_denied.html"), 403


@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="Page or transaction not found."), 404


@app.errorhandler(500)
def internal_error(_):
    return render_template("error.html", code=500, message="A system error occurred. Check server logs for technical details."), 500


if __name__ == "__main__":
    init_db()
    app.run(debug=os.environ.get("FLASK_DEBUG","0")=="1", host="127.0.0.1", port=int(os.environ.get("PORT","5000")))
