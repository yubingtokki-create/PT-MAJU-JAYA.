from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
import hashlib
import json
import secrets
import sqlite3
from database import transaction, get_connection

TAX_RATE = Decimal("0.11")
MAX_DISCOUNT = Decimal("10")

STATUS_TRANSITIONS = {
    "DRAFT": {"SUBMITTED"},
    "SUBMITTED": {"PENDING CREDIT APPROVAL", "READY FOR SHIPPING", "DRAFT"},
    "PENDING CREDIT APPROVAL": {"APPROVED", "REJECTED"},
    "REJECTED": {"DRAFT"},
    "APPROVED": {"READY FOR SHIPPING"},
    "READY FOR SHIPPING": {"PARTIALLY SHIPPED", "FULLY SHIPPED"},
    "PARTIALLY SHIPPED": {"PARTIALLY SHIPPED", "FULLY SHIPPED"},
    "FULLY SHIPPED": set(),
    "COMPLETED": set(),
}


def now_iso():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def money(value):
    try:
        return Decimal(str(value or 0)).quantize(Decimal("0.01"))
    except (InvalidOperation, TypeError):
        return Decimal("0.00")


def generate_number(conn, prefix, table, column, year=None, width=6):
    year = year or datetime.now().year
    pattern = f"{prefix}-{year}-%"
    row = conn.execute(f"SELECT {column} AS num FROM {table} WHERE {column} LIKE ? ORDER BY {column} DESC LIMIT 1", (pattern,)).fetchone()
    next_n = 1
    if row and row["num"]:
        try:
            next_n = int(row["num"].split("-")[-1]) + 1
        except ValueError:
            next_n = 1
    return f"{prefix}-{year}-{next_n:0{width}d}"


def generate_simple_number(conn, prefix, table, column, width=6):
    pattern = f"{prefix}-%"
    row = conn.execute(f"SELECT {column} AS num FROM {table} WHERE {column} LIKE ? ORDER BY {column} DESC LIMIT 1", (pattern,)).fetchone()
    next_n = 1
    if row and row["num"]:
        try:
            next_n = int(row["num"].split("-")[-1]) + 1
        except ValueError:
            next_n = 1
    return f"{prefix}-{next_n:0{width}d}"


def add_audit(user, action, module, record_id=None, old_value=None, new_value=None, result="SUCCESS", reason=None, conn=None):
    should_close = False
    if conn is None:
        conn = get_connection()
        should_close = True
    try:
        role = user["role_name"] if user else "ANONYMOUS"
        user_id = user["user_id"] if user else None
        ip = None
        session_id = None
        try:
            from flask import request, session
            ip = request.remote_addr
            session_id = session.get("user_id") if session else None
        except (RuntimeError, ModuleNotFoundError):
            pass
        conn.execute(
            """INSERT INTO audit_logs(user_id,user_role,action,module,record_id,old_value,new_value,ip_address,session_id,result,reason)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (user_id, role, action, module, str(record_id) if record_id is not None else None,
             json.dumps(old_value, default=str) if isinstance(old_value, (dict, list)) else old_value,
             json.dumps(new_value, default=str) if isinstance(new_value, (dict, list)) else new_value,
             ip, str(session_id) if session_id else None, result, reason),
        )
        if should_close:
            conn.commit()
    finally:
        if should_close:
            conn.close()


def add_notification(user_id, message, module, record_id=None, conn=None):
    should_close = False
    if conn is None:
        conn = get_connection()
        should_close = True
    try:
        conn.execute(
            "INSERT INTO notifications(user_id,message,module,record_id) VALUES(?,?,?,?)",
            (user_id, message, module, record_id),
        )
        if should_close:
            conn.commit()
    finally:
        if should_close:
            conn.close()


def notify_role(role_name, message, module, record_id=None, exclude_user_id=None, conn=None):
    should_close = False
    if conn is None:
        conn = get_connection()
        should_close = True
    try:
        rows = conn.execute(
            """SELECT u.user_id FROM users u JOIN roles r ON r.role_id=u.role_id
               WHERE r.role_name=? AND u.is_active=1""", (role_name,)
        ).fetchall()
        for r in rows:
            if exclude_user_id and r["user_id"] == exclude_user_id:
                continue
            add_notification(r["user_id"], message, module, record_id, conn)
        if should_close:
            conn.commit()
    finally:
        if should_close:
            conn.close()


def validate_customer_active(conn, customer_id):
    customer = conn.execute("SELECT * FROM customers WHERE customer_id=?", (customer_id,)).fetchone()
    if not customer:
        raise ValueError("Customer does not exist.")
    if customer["customer_status"] != "ACTIVE":
        raise ValueError("Customer is inactive and cannot be used for a new Sales Order.")
    return customer


def validate_product_active(conn, product_id):
    product = conn.execute("SELECT * FROM products WHERE product_id=?", (product_id,)).fetchone()
    if not product:
        raise ValueError("Product does not exist.")
    if product["product_status"] != "ACTIVE":
        raise ValueError("Product is inactive.")
    return product


def calculate_order(lines, shipping_cost):
    subtotal = Decimal("0")
    discount = Decimal("0")
    max_discount = Decimal("0")
    normalized = []
    for line in lines:
        qty = money(line["quantity"])
        price = money(line["unit_price"])
        disc_pct = money(line.get("discount_percentage", 0))
        if qty <= 0:
            raise ValueError("Quantity must be greater than 0.")
        if price < 0:
            raise ValueError("Unit price cannot be negative.")
        if disc_pct < 0 or disc_pct > 100:
            raise ValueError("Discount must be between 0% and 100%.")
        line_subtotal = (qty * price).quantize(Decimal("0.01"))
        disc_amt = (line_subtotal * disc_pct / Decimal("100")).quantize(Decimal("0.01"))
        subtotal += line_subtotal
        discount += disc_amt
        max_discount = max(max_discount, disc_pct)
        normalized.append({**line, "quantity": qty, "unit_price": price, "discount_percentage": disc_pct,
                           "line_subtotal": line_subtotal, "discount_amount": disc_amt})
    taxable = subtotal - discount
    tax = (taxable * TAX_RATE).quantize(Decimal("0.01"))
    shipping = money(shipping_cost)
    grand_total = (taxable + tax + shipping).quantize(Decimal("0.01"))
    return normalized, subtotal, discount, tax, grand_total, max_discount


def get_customer_ar(conn, customer_id, exclude_invoice_id=None):
    sql = """SELECT COALESCE(SUM(i.invoice_amount),0) billed,
                    COALESCE(SUM(CASE WHEN i.invoice_status!='CANCELLED' THEN (
                        i.invoice_amount - COALESCE((SELECT SUM(cr.amount) FROM cash_receipts cr WHERE cr.invoice_id=i.invoice_id AND cr.status='POSTED'),0)
                        - COALESCE((SELECT SUM(cn.amount-cn.applied_amount) FROM credit_notes cn WHERE cn.invoice_id=i.invoice_id AND cn.status IN ('OPEN','APPLIED')),0)
                    ) ELSE 0 END),0) outstanding
             FROM invoices i WHERE i.customer_id=?"""
    params = [customer_id]
    if exclude_invoice_id:
        sql += " AND i.invoice_id<>?"
        params.append(exclude_invoice_id)
    row = conn.execute(sql, params).fetchone()
    return money(row["outstanding"] or 0)


def calculate_available_credit(conn, customer_id, order_amount):
    customer = conn.execute("SELECT credit_limit FROM customers WHERE customer_id=?", (customer_id,)).fetchone()
    outstanding = get_customer_ar(conn, customer_id)
    limit = money(customer["credit_limit"])
    available = limit - outstanding
    return limit, outstanding, money(available), (available >= money(order_amount))


def require_transition(old_status, new_status):
    if new_status not in STATUS_TRANSITIONS.get(old_status, set()):
        raise ValueError(f"Invalid status transition: {old_status} → {new_status}.")


def update_invoice_status(conn, invoice_id):
    invoice = conn.execute("SELECT * FROM invoices WHERE invoice_id=?", (invoice_id,)).fetchone()
    if not invoice:
        return None
    paid = money(conn.execute("SELECT COALESCE(SUM(amount),0) total FROM cash_receipts WHERE invoice_id=? AND status='POSTED'", (invoice_id,)).fetchone()["total"])
    credits = money(conn.execute("SELECT COALESCE(SUM(amount-applied_amount),0) remaining FROM credit_notes WHERE invoice_id=? AND status IN ('OPEN','APPLIED')", (invoice_id,)).fetchone()["remaining"])
    outstanding = max(Decimal("0"), money(invoice["invoice_amount"]) - paid - credits)
    if paid + credits <= 0:
        status = "UNPAID"
    elif outstanding <= 0:
        status = "PAID"
    else:
        status = "PARTIAL"
    conn.execute("UPDATE invoices SET paid_amount=?, outstanding_amount=?, invoice_status=? WHERE invoice_id=?", (paid, outstanding, status, invoice_id))
    return {"paid": paid, "credits": credits, "outstanding": outstanding, "status": status}


def post_accounting_entry(conn, user_id, source_type, source_id, description, lines, entry_date=None):
    entry_number = generate_number(conn, "JE", "accounting_entries", "entry_number")
    row = conn.execute(
        "INSERT INTO accounting_entries(entry_number,entry_date,source_type,source_id,description,created_by) VALUES(?,?,?,?,?,?)",
        (entry_number, entry_date or date.today().isoformat(), source_type, source_id, description, user_id),
    )
    entry_id = row.lastrowid
    for account_id, debit, credit, ref in lines:
        if money(debit) > 0:
            conn.execute("INSERT INTO accounting_entry_lines(entry_id,account_id,debit,credit,reference_text) VALUES(?,?,?,?,?)", (entry_id, account_id, money(debit), Decimal("0"), ref))
        elif money(credit) > 0:
            conn.execute("INSERT INTO accounting_entry_lines(entry_id,account_id,debit,credit,reference_text) VALUES(?,?,?,?,?)", (entry_id, account_id, Decimal("0"), money(credit), ref))
        else:
            raise ValueError("Accounting line must have a debit or credit amount.")
    return entry_id, entry_number


def refresh_product_stock(conn, product_id):
    total = money(conn.execute("SELECT COALESCE(SUM(quantity),0) qty FROM inventory_stock WHERE product_id=?", (product_id,)).fetchone()["qty"])
    conn.execute("UPDATE products SET available_stock=?, updated_date=? WHERE product_id=?", (total, now_iso(), product_id))
    return total


def inventory_adjust(conn, product_id, warehouse_id, delta, user_id, movement_type, reference_type=None, reference_id=None, reason=None, unit_cost=0):
    row = conn.execute("SELECT * FROM inventory_stock WHERE product_id=? AND warehouse_id=?", (product_id, warehouse_id)).fetchone()
    current = money(row["quantity"] if row else 0)
    new_qty = current + money(delta)
    if new_qty < 0:
        raise ValueError("Inventory quantity cannot be negative.")
    if row:
        conn.execute("UPDATE inventory_stock SET quantity=? WHERE inventory_stock_id=?", (new_qty, row["inventory_stock_id"]))
    else:
        conn.execute("INSERT INTO inventory_stock(product_id,warehouse_id,quantity) VALUES(?,?,?)", (product_id, warehouse_id, new_qty))
    movement_number = generate_number(conn, "IM", "inventory_movements", "movement_number")
    conn.execute(
        "INSERT INTO inventory_movements(movement_number,product_id,warehouse_id,movement_type,quantity_change,reference_type,reference_id,reason,unit_cost,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (movement_number, product_id, warehouse_id, movement_type, money(delta), reference_type, reference_id, reason, money(unit_cost), user_id),
    )
    refresh_product_stock(conn, product_id)
    return current, new_qty


def verify_customer_email(conn, customer_id, code):
    row = conn.execute("SELECT * FROM customers WHERE customer_id=?", (customer_id,)).fetchone()
    if not row:
        raise ValueError("Customer does not exist.")
    if row["email_verified"]:
        return True
    if not row["verification_code_hash"] or not row["verification_expires_at"]:
        raise ValueError("No active verification code. Please send a new code.")
    if datetime.now() > datetime.fromisoformat(row["verification_expires_at"]):
        raise ValueError("Verification code has expired.")
    expected = hashlib.sha256(code.encode()).hexdigest()
    if expected != row["verification_code_hash"]:
        raise ValueError("Invalid verification code.")
    conn.execute("UPDATE customers SET email_verified=1, verification_code_hash=NULL, verification_expires_at=NULL, updated_date=? WHERE customer_id=?", (now_iso(), customer_id))
    return True


def issue_customer_verification_code(conn, customer_id):
    code = f"{secrets.randbelow(1000000):06d}"
    expires = datetime.now() + timedelta(minutes=10)
    code_hash = hashlib.sha256(code.encode()).hexdigest()
    conn.execute("UPDATE customers SET verification_code_hash=?, verification_expires_at=?, updated_date=? WHERE customer_id=?", (code_hash, expires.isoformat(timespec='seconds'), now_iso(), customer_id))
    return code, expires
