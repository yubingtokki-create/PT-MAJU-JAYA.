# PT Maju Jaya AIS — Design Summary (A–K)

## A. System Architecture

1. Authentication: login, logout, password hashing, session.
2. Authorization/RBAC: role + permission records and server-side route/action checks.
3. Master Data: Customer, Product, Payment Terms, Warehouse, COA, Product Account Mapping.
4. Transaction Processing: Sales Order, Credit Approval, Shipping, Invoice, Cash Receipt, Inventory and Bank Reconciliation.
5. Business Rules: centralized service functions validate active master data, totals, stock, credit, billing and payment.
6. Approval Workflow: Credit Officer and configurable Manager discount approval.
7. Accounting Integration: simplified journal entries traceable to operational source documents.
8. Inventory Integration: per-location stock plus movement ledger.
9. Audit: successful and blocked critical actions are logged.
10. Reporting: dashboard and reports query SQLite transactional data.

## B. Database ERD

```text
ROLES ───< USERS
ROLES >──< PERMISSIONS via ROLE_PERMISSIONS
PAYMENT_TERMS ───< CUSTOMERS
CUSTOMERS ───< SALES_ORDERS ───< SALES_ORDER_DETAILS >── PRODUCTS
SALES_ORDERS ───0..1 CREDIT_APPROVALS
SALES_ORDERS ───< SHIPPINGS ───< SHIPPING_DETAILS >── PRODUCTS
SHIPPINGS ───0..1 INVOICES ───< INVOICE_DETAILS
INVOICES ───< CASH_RECEIPTS
PRODUCTS ───1 PRODUCT_ACCOUNTS >── CHART_OF_ACCOUNTS
PRODUCTS ───< INVENTORY_STOCK >── WAREHOUSES
BANK_TRANSACTIONS ───0..1 BANK_RECONCILIATIONS >── CASH_RECEIPTS
SALES_ORDERS ───0..1 MANAGER_APPROVALS
```

## C. Database Relationship Explanation

- Customer 1:M Sales Orders.
- Sales Order 1:M Sales Order Details.
- Sales Order 0:1 Credit Approval for CREDIT transactions.
- Sales Order 1:M Shipping transactions.
- Shipping 1:M Shipping Details.
- Shipping 0:1 Invoice in this prototype; multiple shipments against one SO can therefore be billed separately.
- Invoice 1:M Cash Receipts.
- Product 1:M Sales Order Details.
- Product 1:1 Product Account Mapping.
- Bank Transaction 0:1 Bank Reconciliation record.
- Customer/Invoice/Receipt relationships calculate AR from actual transactions.

## D. Role & Permission Matrix

The database stores role and permission assignments. The sidebar is filtered by permission, but protected route/action endpoints perform backend permission checks again.

## E. Revenue Cycle Workflow

```text
Customer
  ↓
Sales Order DRAFT
  ↓ Submit
Submitted
  ├─ CASH → Ready for Shipping
  └─ CREDIT → Pending Credit Approval
                     ↓
              Approved / Rejected
                     ↓
               Ready for Shipping
                     ↓
         Shipping + Inventory Update
                     ↓
                   Invoice
                     ↓
              Accounts Receivable
                     ↓
               Cash Receipt(s)
                     ↓
              Bank Reconciliation
                     ↓
               Reports / Dashboard
                     ↓
                 Audit Trail
```

Exception paths remain traceable: rejection → controlled revision, stock shortage → blocked/partial shipment, partial shipment → subsequent shipment, partial payment → additional payment, bank mismatch → exception.

## F. Internal Control Matrix

| Control | Implementation |
|---|---|
| Authentication | PBKDF2-SHA256 password hashing and login session |
| Authorization | Role-permission records + backend decorators |
| SoD | Separate Sales, Credit, Warehouse, Accounting, Cashier responsibilities |
| Credit limit | Available credit recalculated from current AR |
| Shipping approval | CREDIT shipping requires approved credit |
| Stock | Per-location stock validation before shipment commit |
| Quantity | Shipment <= remaining ordered quantity |
| Price | SO uses Product Master selling price |
| Discount | >10% requires Manager approval in prototype |
| Billing | Invoice requires shipped goods |
| Cash receipt | Receipt references an invoice and cannot exceed outstanding |
| Master data | Active Customer/Product validation |
| COA mapping | Product-to-COA mapping used in simplified accounting postings |
| Bank reconciliation | Matched, unreconciled and exception states |
| Audit trail | User/timestamp/action/module/record/result/reason |
| Traceability | Customer → SO → CA → SH → INV → RC chain |

## G. Business Rules

1. Inactive customer → block new SO.
2. Inactive product → block SO line.
3. Credit sale → mandatory credit approval.
4. Pending/rejected credit → shipping blocked.
5. Shipment > remaining → blocked.
6. Shipment > available stock at selected warehouse → blocked.
7. Sales Order may exist despite insufficient stock.
8. Partial shipment is allowed line-by-line.
9. Only confirmed shipped quantities are billable.
10. Same shipment cannot be invoiced twice.
11. Payment <= 0 or payment > outstanding → blocked.
12. Invoice status is derived from posted receipts.
13. Discount above threshold requires manager approval.
14. Rejected SOs are not directly edited into approved; a new revision record can be created.
15. Historical financial transactions are not hard-deleted.

## H. Accounting + Inventory Integration

Operational events produce accounting information:

- GRN: Inventory Dr / AP Cr.
- Shipping: COGS Dr / Inventory Cr.
- Invoice: AR Dr / Revenue Cr / VAT Payable Cr.
- Cash Receipt: Cash/Bank Dr / AR Cr.

Inventory quantity is tracked per location, while inventory value is shown separately using standard cost. Product account mapping determines the relevant accounting classification.

## I. Test Plan

- 50 documented test cases in `TEST_CASES.md`.
- `tests/smoke_sqlite.py`: database integrity, required tables, seeded coverage, password verification and non-negative inventory.
- `tests/test_core_logic.py`: password hashing, order calculation, input bounds, and status transition control.
- Flask UI integration cases can be executed after installing dependencies.

## J. UI/UX Structure

- Login page.
- Brown corporate ERP theme.
- Fixed left sidebar with permission-aware navigation.
- Sticky top bar with company, current page, employee identity, notification count and logout.
- KPI cards with live SQLite metrics.
- Transaction detail pages include status, next action, source/related documents and audit context.
- Tables and forms are responsive for desktop/tablet.

## K. Project Structure

See `README.md` for the full project tree. Main layers are `app.py`, `auth.py`, `security.py`, `database.py`, `services.py`, SQL schema/seed, Jinja templates and static assets.
